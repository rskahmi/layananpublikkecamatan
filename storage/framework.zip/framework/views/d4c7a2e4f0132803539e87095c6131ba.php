<?php $__env->startSection('headers'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
<?php $__env->stopSection(); ?>


<div class="animate__animated animate__fadeInUp" id="mapid"></div>


<?php if (isset($component)) { $__componentOriginal3c9c42741016133644fbaa55b5e4738c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c9c42741016133644fbaa55b5e4738c = $attributes; } ?>
<?php $component = App\View\Components\Modals\BaseModal::resolve(['id' => 'exampleModal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.BaseModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\BaseModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <h3 class="popup-title" id="judul-berita"></h3>
        </div>
        <div class="col-12 mt-2">
            <img id="gambarBerita" src="" alt="Gambar" />
        </div>
        <div class="col-12">
            <div class="deskripsi mt-3">
                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Deskripsi','id' => 'deskripsi'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
            </div>
            <div class="deskripsi mt-3">
                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Kelompok binaan','id' => 'kelompok'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
            </div>
            <div class="deskripsi mt-3">
                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Alamat','id' => 'alamat'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
            </div>
            <div class="deskripsi mt-3">
                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Kontak','id' => 'kontak'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c9c42741016133644fbaa55b5e4738c)): ?>
<?php $attributes = $__attributesOriginal3c9c42741016133644fbaa55b5e4738c; ?>
<?php unset($__attributesOriginal3c9c42741016133644fbaa55b5e4738c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c9c42741016133644fbaa55b5e4738c)): ?>
<?php $component = $__componentOriginal3c9c42741016133644fbaa55b5e4738c; ?>
<?php unset($__componentOriginal3c9c42741016133644fbaa55b5e4738c); ?>
<?php endif; ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://unpkg.com/leaflet"></script>
    <script src="https://unpkg.com/leaflet-fullscreen/dist/Leaflet.fullscreen.min.js"></script>

    <?php echo e($slot); ?>

    <script>
        var map = L.map('mapid').setView([1.6692, 101.4478], 13);

        // Define base layers
        var streetMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        });

        var satelliteMap = L.tileLayer('https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', {
            maxZoom: 20,
            subdomains:['mt0','mt1','mt2','mt3']
        });

        var baseLayers = {
            "Street Map": streetMap,
            "Satellite Map": satelliteMap
        };

        L.control.layers(baseLayers).addTo(map);

        streetMap.addTo(map);

        var pointData = [];

        wilayah.forEach(function(data) {
            var singlePointData = {
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [data.longitude, data.latitude]
                },
                "properties": {
                    "alamat": data.alamat,
                    "latitude": data.latitude,
                    "longitude": data.longitude,
                    "kelurahan": data.kelurahan,
                    "kecamatan": data.kecamatan,
                    "kota": data.kota,
                    "jumlah": {
                        "tjsl": data.tjsl_count,
                        "tjsl_percent": data.tjsl_count === 0 ? 0 : (data.tjsl_count / (data.tjsl_count + data.program_count) * 100),
                        "program": data.program_count,
                        "program_percent": data.program_count === 0 ? 0 : (data.program_count / (data.tjsl_count + data.program_count) * 100),
                        "max": data.tjsl_count + data.program_count,
                    }
                },
                "tjsl": [],
                "program": []
            };

            singlePointData.tjsl = data.tjsl
            singlePointData.program = data.program

            pointData.push(singlePointData);
        });

        pointData.forEach(function(data, index) {
            var latitude = data.geometry.coordinates[1];
            var longitude = data.geometry.coordinates[0];
            var wilayah = data.properties

            var marker = L.marker([latitude, longitude]).addTo(map);

            marker.bindPopup(
                '<div class="leaflet-popup-custom popup-custom-width">' +
                    '<h5 class="card-title">Resume</h5>' +
                    '<span class="subtitle">Wilayah ' + wilayah.alamat + ', ' + wilayah.kelurahan + ', ' + wilayah.kecamatan + '</span>' +
                    '<div class="progress-bar-berita">' +
                        '<div class="row d-flex align-items-center">' +
                            '<div class="col-8">' +
                                '<div class="progress">' +
                                    '<div class="progress-bar bg-progress-danger" role="progressbar" style="width: '+ data
                .properties.jumlah.program_percent +'%;" aria-valuenow="'+ data
                .properties.jumlah.program +'" aria-valuemin="0" aria-valuemax="'+ data
                .properties.jumlah.max +'">' +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                            '<div class="col-1 d-flex align-items-center gap-2">' +
                                '<span class="value">'+ data
                .properties.jumlah.program +'</span>' +
                                '<button class="btn btn-dark text-uppercase"  class="program-link" id="showProgram' +
                index + '">detail</button>' +
                            '</div>' +
                        '</div>' +
                        '<span class="title ms-2">Program Unggulan</span>' +
                    '</div>' +
                    '<div class="progress-bar-berita mt-2">' +
                        '<div class="row d-flex align-items-center">' +
                            '<div class="col-8">' +
                                '<div class="progress">' +
                                    '<div class="progress-bar bg-progress-success" role="progressbar" style="width: '+ data
                .properties.jumlah.tjsl_percent +'%;" aria-valuenow="'+ data
                .properties.jumlah.tjsl +'" aria-valuemin="0" aria-valuemax="'+ data
                .properties.jumlah.max +'">' +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                            '<div class="col-1 d-flex align-items-center gap-2">' +
                                '<span class="value">'+ data
                .properties.jumlah.tjsl +'</span>' +
                                '<button class="btn btn-dark text-uppercase" class="program-link" id="showTjsl' +
                index + '">detail</button>' +
                            '</div>' +
                        '</div>' +
                        '<span class="title ms-2">TJSL</span>' +
                    '</div>' +
                '</div>' +
                '<div class="d-flex justify-content-end"><button class="btn btn-primary" id="closePopupBtn' +
                index + '">Ok</button></div>' +
                '</div>'
            ,{
                    closeButton: false
                }
            );

            marker.on('popupopen', function() {
                document.querySelector('#closePopupBtn' + index).addEventListener('click', function() {
                    marker.closePopup();
                });

                document.querySelector('#showTjsl' + index).addEventListener('click', function() {
                    var markerLatLng = marker.getLatLng();
                    var newPopupLatLng = L.latLng(markerLatLng.lat, markerLatLng.lng);

                    var newPopupContent =
                        '<table id="dataTable" class="display table table-responsive dataTable popup-custom-width">' +
                        '<thead>' +
                        '<th>PROGRAM</th>' +
                        '<th>TANGGAL</th>' +
                        '<th>PIC</th>' +
                        '</thead>' +
                        '<tbody>';

                    pointData[index].tjsl.forEach(function(tjslItem, tjslIndex) {
                        newPopupContent += '<tr>' +
                            '<td>' + tjslItem.nama + '</td>' +
                            '<td>' + formatDfy(tjslItem.tanggal) + '</td>' +
                            '<td>' + tjslItem.pic + '</td>' +
                            '</tr>';
                    });

                    newPopupContent += '</tbody>' +
                        '</table>';

                    var newPopup = L.popup({
                            minWidth: 460,
                            maxWidth: 500
                        })
                        .setLatLng(newPopupLatLng)
                        .setContent(newPopupContent)
                        .openOn(map);
                });

                document.querySelector('#showProgram' + index).addEventListener('click', function() {
                    var markerLatLng = marker.getLatLng();
                    var newPopupLatLng = L.latLng(markerLatLng.lat, markerLatLng.lng);

                    var newPopupContent =
                        '<table id="dataTable" class="display table table-responsive dataTable popup-custom-width">' +
                        '<thead>' +
                        '<th>NAMA PROGRAM</th>' +
                        '<th>KELOMPOK BINAAN</th>' +
                        '<th>KONTAK</th>' +
                        '<th>AKSI</th>' +
                        '</thead>' +
                        '<tbody>';

                    pointData[index].program.forEach(function(programItem, programIndex) {
                        newPopupContent += '<tr>' +
                            '<td>' + programItem.nama_program  + '</td>' +
                            '<td>' + programItem.mitra_binaan  + '</td>' +
                            '<td>' + programItem.contact + '</td>' +
                            '<td>' + '<button class="text-uppercase detail-program btn btn-dark" data-nama="'+ programItem.nama_program +'" data-deskripsi="'+ programItem.deskripsi +'" data-kelompok="'+ programItem.mitra_binaan +'" data-kontak="' + programItem.contact +'" data-alamat="'+ wilayah.alamat + ', ' + wilayah.kelurahan + ', '+ wilayah.kecamatan +'" data-ketua="'+  programItem.ketua_kelompok +'" data-gambar="'+ programItem.gambar +'" onclick="showDetailProgram(event)">detail' +
                                '</button>'+'</td>' +
                            '</tr>';
                    });

                    newPopupContent += '</tbody>' +
                        '</table>';

                    var newPopup = L.popup({
                            minWidth: 460,
                            maxWidth: 500
                        })
                        .setLatLng(newPopupLatLng)
                        .setContent(newPopupContent)
                        .openOn(map);
                });

            });
        });

        map.addControl(new L.Control.Fullscreen());


        var app_url = "<?php echo e(config('app.url')); ?>"

        function showDetailProgram(event) {
            var button = event.target;

            // Get the data-nama attribute value from the clicked button
            var nama = $(button).data('nama');
            var deskripsi = $(button).data('deskripsi');
            var kelompok = $(button).data('kelompok');
            var kontak = $(button).data('kontak');
            var alamat = $(button).data('alamat');
            var ketua = $(button).data('ketua');
            var gambar = $(button).data('gambar');

            $("#judul-berita").html(nama)
            $("#deskripsi").html(deskripsi)
            $("#kelompok").html(kelompok + " (<b>" + ketua + "</b>)")
            $("#alamat").html(alamat)
            $("#kontak").html(kontak)
            $("#gambarBerita").attr('src', app_url + '/storage/images/program-unggulan/' + gambar)
            $("#gambarBerita").attr('alt', 'Gambar ' + nama)

            $("#exampleModal").modal('show')
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\layout\resume.blade.php ENDPATH**/ ?>