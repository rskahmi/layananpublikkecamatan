<?php $__env->startSection('headers'); ?>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Pengajuan Berkas'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8576646e017181f7c8f40714a073405d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8576646e017181f7c8f40714a073405d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Berkas::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.berkas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Berkas::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $attributes = $__attributesOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__attributesOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $component = $__componentOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__componentOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>

    <div class="animate__animated animate__fadeInUp">
        <div class="card table">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-12 col-sm-12 col-md-5">
                        <h4>Aksi Pengajuan</h4>
                    </div>
                    <div class="col-12 col-sm-12 col-md-7 d-flex justify-content-start justify-content-md-end gap-2">
                        <?php if (isset($component)) { $__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6)): ?>
<?php $attributes = $__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6; ?>
<?php unset($__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6)): ?>
<?php $component = $__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6; ?>
<?php unset($__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6); ?>
<?php endif; ?>
                        <?php if(isAdmin()): ?>
                            <button class="btn btn-primary text-capitalize" data-bs-toggle="modal"
                                data-bs-target="#exampleModal">
                                <?php if (isset($component)) { $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Addfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.addfile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Addfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $attributes = $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $component = $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
                                Tambah Berkas
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php $__env->slot('slotHeading'); ?>
                        <tr>
                            <th scope="col" class="w-30">BERKAS</th>
                            <th scope="col">JENIS</th>
                            <th scope="col">NAMA</th>
                            <th scope="col">NO HP</th>
                            <th scope="col">ANGGARAN</th>
                            <th scope="col">BATAS KONFIRMASI</th>
                            <th scope="col">STATUS</th>
                            <?php if(isAllAdmin()): ?>
                                <th class="text-center">AKSI</th>
                            <?php endif; ?>
                        </tr>
                    <?php $__env->endSlot(); ?>

                    <?php $__env->slot('slotBody'); ?>

                        <?php $__currentLoopData = $berkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="w-30">
                                    <h5><?php echo e($item->nama_berkas); ?></h5>
                                    <span><?php echo e($item->nomor_berkas); ?>, <?php echo e(format_dfy($item->tanggal)); ?></span>
                                </td>
                                <td>
                                    <?php echo e($item->jenis); ?>

                                </td>
                                <td>
                                    <h6><?php echo e($item->nama_pengirim); ?></h6>
                                    <?php if($item->proposal): ?>
                                        <span><?php echo e($item->proposal->lembaga->nama_lembaga); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a target="_blank" href="https://wa.me/<?php echo e(checkNumber($item->contact)); ?>" class="text-decoration-underline"><?php echo e(checkNumber($item->contact)); ?></a>
                                </td>
                                <td>
                                    <?php echo e($item->proposal !== null ? formatRupiah($item->proposal->anggaran) : '-'); ?>

                                </td>
                                <td>
                                    <?php echo e(format_dfy($item->batas_konfirmasi)); ?>

                                </td>
                                <td>
                                    <?php if($item->proposal !== null): ?>
                                        <span
                                            class="badge text-capitalize <?php echo e(isStatusDiterima($item->proposal->status) ? 'bg-success' : (isStatusProses($item->proposal->status) ? 'bg-warning' : (isStatusDiajukan($item->proposal->status) ? 'bg-warning-subtle text-dark' : 'bg-danger'))); ?>"><?php echo e($item->proposal->status); ?></span>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="aksi">
                                        <?php if(isAllAdmin()): ?>
                                            <?php if(isAdmin()): ?>
                                                <a href="##edit" id="edit"
                                                    <?php if(!$item->proposal): ?> onclick="modalEditBerkas('<?php echo e(route('berkas.update', ['id' => $item->id])); ?>',
                                                '<?php echo e($item->nomor_berkas); ?>',
                                                '<?php echo e($item->nama_berkas); ?>',
                                                '<?php echo e($item->nama_pengirim); ?>',
                                                '<?php echo e($item->tanggal); ?>',
                                                '<?php echo e($item->jenis); ?>',
                                                '<?php echo e($item->contact); ?>')"
                                                <?php else: ?>
                                                onclick="modalEditBerkas('<?php echo e(route('berkas.update', ['id' => $item->id])); ?>',
                                                '<?php echo e($item->nomor_berkas); ?>',
                                                '<?php echo e($item->nama_berkas); ?>',
                                                '<?php echo e($item->nama_pengirim); ?>',
                                                '<?php echo e($item->tanggal); ?>',
                                                '<?php echo e($item->jenis); ?>',
                                                '<?php echo e($item->contact); ?>',
                                                '<?php echo e($item->proposal->lembaga->id); ?>',
                                                '<?php echo e($item->proposal->wilayah->id); ?>',
                                                '<?php echo e($item->proposal->jenis); ?>')" <?php endif; ?>
                                                    data-bs-toggle="modal" data-bs-target="#editModal">
                                                    <?php if (isset($component)) { $__componentOriginal6a24e45ead027dffc98dad0a673cefeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Edit::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Edit::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $attributes = $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $component = $__componentOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
                                                </a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('berkas.detail', ['id' => $item->id])); ?>">
                                                <?php if (isset($component)) { $__componentOriginal334a1e8d53b1004ac9cb270596a849ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Info::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Info::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $attributes = $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $component = $__componentOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
                                            </a>
                                            <?php if(isAdmin()): ?>
                                                <?php if (isset($component)) { $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Delete::resolve(['action' => ''.e(route('berkas.destroy', ['id' => $item->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Delete::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $attributes = $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $component = $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
    </div>


    <?php if(isAllAdmin()): ?>
        <!-- Modal -->
        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['action' => ''.e(route('berkas.store')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="exampleModalLabel">Tambah Pengajuan</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="alert alert-success mt-2" style="display: none" role="alert" id="alertWilayahModal">
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nomor Berkas','name' => 'nomor_berkas','placeholder' => 'Masukkan Nomor Berkas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nama Berkas','name' => 'nama_berkas','placeholder' => 'Masukkan Nama Berkas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2 = $attributes; } ?>
<?php $component = App\View\Components\Forms\File::resolve(['name' => 'file_berkas','label' => 'File Berkas','placeholder' => 'Upload File'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\File::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $attributes = $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $component = $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Jenis Berkas','name' => 'jenis','placeholder' => 'Masukkan Jenis Berkas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="Surat">Surat</option>
                        <option value="Proposal">Proposal</option>
                        <option value="Undangan">Undangan</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                </div>
                <div id="proposal-only" class="animate__animated animate__fadeInUp" style="display: none;">
                    <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Jenis Program','name' => 'jenis_kegiatan','placeholder' => 'Masukkan Jenis Program'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <option value="terprogram">Tjsl Terprogram</option>
                            <option value="tidak terprogram">Tjsl Tidak Terprogram</option>
                            <option value="sponsorship">Sponsorship</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginalbb1af718931bc8631c45d20c54e9e755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb1af718931bc8631c45d20c54e9e755 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select2::resolve(['label' => 'Lembaga','name' => 'lembaga-select'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <?php $__currentLoopData = $lembaga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($item->id); ?>><?php echo e($item->nama_lembaga); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $attributes = $__attributesOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $component = $__componentOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__componentOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginalbb1af718931bc8631c45d20c54e9e755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb1af718931bc8631c45d20c54e9e755 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select2::resolve(['label' => 'Wilayah','name' => 'wilayah-select'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <?php $__currentLoopData = $wilayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($item->id); ?>><?php echo e($item->alamat); ?>,<?php echo e($item->kelurahan); ?>,
                                    <?php echo e($item->kecamatan); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $attributes = $__attributesOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $component = $__componentOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__componentOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nama Pemohon','name' => 'nama_pemohon','placeholder' => 'Masukkan Nama Pemohon'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'No HP Pemohon','name' => 'contact','placeholder' => 'Masukkan No HP Pemohon'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal2c26bbe9b818509eee938912deb14a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c26bbe9b818509eee938912deb14a55 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Date::resolve(['label' => 'Tanggal Pengajuan','name' => 'tanggal','placeholder' => 'Pilih Tanggal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Date::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $attributes = $__attributesOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__attributesOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $component = $__componentOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__componentOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['action' => ''.e(route('berkas')).'','id' => 'editModal','isUpdate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="editModalLabel">Edit Pengajuan</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="alert alert-success mt-2" style="display: none" role="alert" id="alertWilayahModal">
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nomor Berkas','name' => 'edtNomorBerkas','placeholder' => 'Masukkan Nomor Berkas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nama Berkas','name' => 'edtNamaBerkas','placeholder' => 'Masukkan Nama Berkas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Jenis Berkas','name' => 'edtJenis','placeholder' => 'Masukkan Jenis Berkas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="Surat">Surat</option>
                        <option value="Proposal">Proposal</option>
                        <option value="Undangan">Undangan</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                </div>
                <div id="edt-proposal-only" class="d-none">
                    <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Jenis Program','name' => 'edtJenis','placeholder' => 'Masukkan Jenis Program'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <option value="terprogram">Tjsl Terprogram</option>
                            <option value="tidak terprogram">Tjsl Tidak Terprogram</option>
                            <option value="sponsorship">Sponsorship</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                    </div>
                    <div class="mb-3" id="containerEdtLembaga">
                        <?php if (isset($component)) { $__componentOriginalbb1af718931bc8631c45d20c54e9e755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb1af718931bc8631c45d20c54e9e755 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select2::resolve(['label' => 'Lembaga','name' => 'edt-lembaga-select'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <?php $__currentLoopData = $lembaga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($item->id); ?>><?php echo e($item->nama_lembaga); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $attributes = $__attributesOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $component = $__componentOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__componentOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
                    </div>
                    <div class="mb-3" id="containerEdtWilayah">
                        <?php if (isset($component)) { $__componentOriginalbb1af718931bc8631c45d20c54e9e755 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb1af718931bc8631c45d20c54e9e755 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select2::resolve(['label' => 'Wilayah','name' => 'edt-wilayah-select'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <?php $__currentLoopData = $wilayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($item->id); ?>><?php echo e($item->alamat); ?>, <?php echo e($item->kelurahan); ?>,
                                    <?php echo e($item->kecamatan); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $attributes = $__attributesOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__attributesOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb1af718931bc8631c45d20c54e9e755)): ?>
<?php $component = $__componentOriginalbb1af718931bc8631c45d20c54e9e755; ?>
<?php unset($__componentOriginalbb1af718931bc8631c45d20c54e9e755); ?>
<?php endif; ?>
                    </div>

                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal2c26bbe9b818509eee938912deb14a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c26bbe9b818509eee938912deb14a55 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Date::resolve(['label' => 'Tanggal Pengajuan','name' => 'edtTanggal','placeholder' => 'Pilih Tanggal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Date::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $attributes = $__attributesOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__attributesOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $component = $__componentOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__componentOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nama Pemohon','name' => 'edtNamaPemohon','placeholder' => 'Masukkan Nama Pemohon'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'No HP Pemohon','name' => 'edtContact','placeholder' => 'Masukkan No HP Pemohon'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>

            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal808e4a2530a7059c88b344fd658b4d28 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal808e4a2530a7059c88b344fd658b4d28 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Wilayah::resolve(['modal' => '#exampleModal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.wilayah'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Wilayah::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal808e4a2530a7059c88b344fd658b4d28)): ?>
<?php $attributes = $__attributesOriginal808e4a2530a7059c88b344fd658b4d28; ?>
<?php unset($__attributesOriginal808e4a2530a7059c88b344fd658b4d28); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal808e4a2530a7059c88b344fd658b4d28)): ?>
<?php $component = $__componentOriginal808e4a2530a7059c88b344fd658b4d28; ?>
<?php unset($__componentOriginal808e4a2530a7059c88b344fd658b4d28); ?>
<?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type='text/javascript'
        src='https://www.bing.com/api/maps/mapcontrol?callback=GetMap&key=<?php echo e(env('BING_API_KEY')); ?>' async defer></script>
    <script src="<?php echo e(asset('assets/user/js/maps.js')); ?>"></script>
    <script>
        gambarHandler('file_berkas')
        select2wilayah("wilayah-select", "exampleModal")
        select2lembaga("lembaga-select", "exampleModal")
        select2wilayah("edt-wilayah-select", "editModal")
        select2lembaga("edt-lembaga-select", "editModal")
        dataTable(7)

        // Check if users select a proposal or surat & undangan
        $('#jenis').change(function() {
            var value = $(this).val()

            if (value.toLowerCase() === "proposal") {
                $('#proposal-only').show()
            } else {
                $('#proposal-only').hide()
            }
        })

        $('#edtJenis').change(function() {
            var value = $(this).val()

            if (value.toLowerCase() === "proposal") {
                if ($("#edt-proposal-only").hasClass("d-none")) {
                    $("#edt-proposal-only").removeClass("d-none");
                }
            } else {
                if (!$("#edt-proposal-only").hasClass("d-none")) {
                    $("#edt-proposal-only").addClass("d-none");
                }
            }
        })

        document.addEventListener("DOMContentLoaded", function() {
            Echo.channel('channel-wilayah')
                .listen('WilayahEvent', (e) => {
                    var data = e.data;

                    var value = data.id
                    var text = data.alamat + ", " + data.kelurahan + ", " + data.kecamatan
                    addDataToSelect2([{
                        value: value,
                        text: text
                    }], '#wilayah-select')

                    addDataToSelect2([{
                        value: value,
                        text: text
                    }], '#edt-wilayah-select')
                });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\berkas\pengajuan.blade.php ENDPATH**/ ?>