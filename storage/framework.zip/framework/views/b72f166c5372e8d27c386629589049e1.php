<?php $__env->startSection('title', 'Detail Rilis'); ?>
<?php $__env->startSection('headers'); ?>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8576646e017181f7c8f40714a073405d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8576646e017181f7c8f40714a073405d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Berkas::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.berkas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Berkas::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $attributes = $__attributesOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__attributesOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $component = $__componentOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__componentOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>

    <div class="row detail-pengajuan">
        <div class="col-11">
            <div class="card standart">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="row">
                                <div class="col-12 mb-2">
                                    <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Judul','subtitle' => ''.e($rilis->judul).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                                </div>
                                <div class="col-12 mb-2">
                                    <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Deskripsi','subtitle' => ''.$rilis->deskripsi.''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                                </div>
                                <div class="col-12 mb-2">
                                    <div class="popup-text">
                                        <h6>Jenis Media</h6>
                                    </div>

                                    <div class="progress-bar-berita mt-2">
                                        <div class="row d-flex align-items-center">
                                            <div class="col-5">
                                                <div class="progress">
                                                    <div class="progress-bar bg-progress-warning" role="progressbar"
                                                        style="width: <?php echo e(parseToPercentage($jumlah_berita_online, $jumlah_berita)); ?>%;"
                                                        aria-valuenow="<?php echo e($jumlah_berita_online); ?>" aria-valuemin="0"
                                                        aria-valuemax="<?php echo e($jumlah_berita); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-1">
                                                <span class="value"><?php echo e($rilis['jumlah_berita_online']); ?></span>
                                            </div>
                                        </div>
                                        <span class="title">Online</span>
                                        <div class="row d-flex align-items-center">
                                            <div class="col-5">
                                                <div class="progress">
                                                    <div class="progress-bar bg-progress-semi-danger" role="progressbar"
                                                        style="width: <?php echo e(parseToPercentage($jumlah_berita_cetak, $jumlah_berita)); ?>%;"
                                                        aria-valuenow="<?php echo e($jumlah_berita_cetak); ?>" aria-valuemin="0"
                                                        aria-valuemax="<?php echo e($jumlah_berita); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-1">
                                                <span class="value"><?php echo e($rilis['jumlah_berita_cetak']); ?></span>
                                            </div>
                                        </div>
                                        <span class="title">Cetak</span>
                                        <div class="row d-flex align-items-center">
                                            <div class="col-5">
                                                <div class="progress">
                                                    <div class="progress-bar bg-progress-more-warning" role="progressbar"
                                                        style="width: <?php echo e(parseToPercentage($jumlah_berita_elektronik, $jumlah_berita)); ?>%;"
                                                        aria-valuenow="<?php echo e($jumlah_berita_elektronik); ?>" aria-valuemin="0"
                                                        aria-valuemax="<?php echo e($jumlah_berita); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-1">
                                                <span class="value"><?php echo e($rilis['jumlah_berita_elektronik']); ?></span>
                                            </div>
                                        </div>
                                        <span class="title">Elektronik</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="popup-text">
                                <h6>Gambar</h6>
                            </div>
                            <img class="rounded mt-1"
                                src="<?php echo e(isFileExists('storage/images/rilis/' . $rilis->gambar, asset('assets/img/dafault/default-bg.png'))); ?>"
                                width="302" height="158" alt="Gambar <?php echo e($rilis->judul); ?>">
                        </div>

                        <div class="col-8">
                            <div class="card table">
                                <div class="card-header">
                                    <div class="row align-items-center">
                                        <div class="col-12 col-sm-12 col-md-5">
                                            <h4>Data Pemberitaan</h4>
                                        </div>
                                        <div
                                            class="col-12 col-sm-12 col-md-7 d-flex justify-content-start justify-content-md-end gap-2">
                                            <?php if(isAllAdmin()): ?>
                                                <button class="btn btn-primary text-capitalize" data-bs-toggle="modal"
                                                    data-bs-target="#tambahPemberitaan">
                                                    <?php if (isset($component)) { $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Addfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.addfile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Addfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $attributes = $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $component = $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
                                                    Tambah
                                                </button>
                                                <select class="form-select" id="jenisMedia" style="max-width: 180px">
                                                    <option selected value="media online">Media Online</option>
                                                    <option value="media cetak">Media Cetak</option>
                                                    <option value="media elektronik">Media Elektronik</option>
                                                </select>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div id="media-online-container">
                                        <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'media-online-dataTable']); ?>
                                            <?php $__env->slot('slotHeading'); ?>
                                                <tr>
                                                    <th scope="col" class="w-25">LINK</th>
                                                    <th scope="col" class="w-35">RESPON</th>
                                                    <th scope="col">JENIS MEDIA</th>
                                                    <?php if(isAllAdmin()): ?>
                                                        <th scope="col" class="text-center">AKSI</th>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php $__env->endSlot(); ?>


                                            <?php $__env->slot('slotBody'); ?>
                                                <?php $__currentLoopData = $pemberitaan_online; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <a
                                                                href="<?php echo e($item->tautan); ?>"><?php echo e(getDomainOnly($item->tautan)); ?></a>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                $respon = $item->respon;
                                                            ?>

                                                            <span
                                                                class="badge text-uppercase <?php echo e(strtolower($respon) == 'positif'
                                                                    ? 'bg-success'
                                                                    : (strtolower($respon) == 'negatif'
                                                                        ? 'bg-danger'
                                                                        : (strtolower($respon) == 'netral'
                                                                            ? 'bg-primary'
                                                                            : ''))); ?>"><?php echo e($respon); ?>

                                                            </span>
                                                        </td>
                                                        <td>
                                                            <span class="badge text-uppercase bg-progress-warning">
                                                                <?php echo e($item->jenis); ?>

                                                            </span>
                                                        </td>
                                                        <?php if(isAllAdmin()): ?>
                                                            <td>
                                                                <div
                                                                    class="aksi d-flex align-items-center justify-content-center">
                                                                    <a class="editClassed" href="##edit" id="edit"
                                                                        data-bs-toggle="modal" data-bs-target="#editModal"
                                                                        onclick="updatePemberitaan(
                                                                        '<?php echo e(route('media.pemberitaan.update', ['id' => $item->id])); ?>',
                                                                        'media online',
                                                                        'positif',
                                                                        '<?php echo e($item->tautan); ?>'
                                                                    )">
                                                                        <?php if (isset($component)) { $__componentOriginal6a24e45ead027dffc98dad0a673cefeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Edit::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Edit::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $attributes = $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $component = $__componentOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
                                                                    </a>
                                                                    <?php if (isset($component)) { $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Delete::resolve(['action' => ''.e(route('media.pemberitaan.destroy', ['id' => $item->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Delete::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $attributes = $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $component = $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
                                                                </div>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__env->endSlot(); ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>

                                        <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'media-online-dataTable']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
                                    </div>

                                    <div id="media-cetak-container" style="display: none;">
                                        <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'media-cetak-dataTable']); ?>
                                            <?php $__env->slot('slotHeading'); ?>

                                                <tr>
                                                    <th scope="col" class="w-25">GAMBAR</th>
                                                    <th scope="col" class="w-35">RESPON</th>
                                                    <th scope="col">JENIS MEDIA</th>
                                                    <?php if(isAllAdmin()): ?>
                                                        <th scope="col" class="text-center">AKSI</th>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php $__env->endSlot(); ?>

                                            <?php $__env->slot('slotBody'); ?>
                                                <?php $__currentLoopData = $pemberitaan_cetak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $gambar = isFileExists(
                                                            'storage/images/pemberitaan/' . $item->gambar,
                                                            asset('assets/img/dafault/default-bg.png'),
                                                        );
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <img class="rounded"
                                                                src="<?php echo e($gambar); ?>"
                                                                width="170" height="83" alt="">
                                                        </td>
                                                        <td>
                                                            <?php
                                                                $respon = $item->respon;
                                                            ?>
                                                            <span
                                                                class="badge text-uppercase <?php echo e(strtolower($respon) == 'positif'
                                                                    ? 'bg-success'
                                                                    : (strtolower($respon) == 'negatif'
                                                                        ? 'bg-danger'
                                                                        : (strtolower($respon) == 'netral'
                                                                            ? 'bg-primary'
                                                                            : ''))); ?>"><?php echo e($respon); ?>

                                                            </span>
                                                        </td>
                                                        <td>
                                                            <span class="badge text-uppercase bg-progress-semi-danger">
                                                                <?php echo e($item->jenis); ?>


                                                            </span>
                                                        </td>
                                                        <?php if(isAllAdmin()): ?>
                                                            <td>
                                                                <div
                                                                    class="aksi d-flex align-items-center justify-content-center">
                                                                    <a class="editClassed" href="##edit" id="edit"
                                                                        data-bs-toggle="modal" data-bs-target="#editModal"
                                                                        onclick="updatePemberitaan(
                                                                        '<?php echo e(route('media.pemberitaan.update', ['id' => $item->id])); ?>',
                                                                        'media cetak',
                                                                        'positif',
                                                                        '<?php echo e($gambar); ?>'
                                                                    )">
                                                                        <?php if (isset($component)) { $__componentOriginal6a24e45ead027dffc98dad0a673cefeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Edit::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Edit::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $attributes = $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $component = $__componentOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
                                                                    </a>
                                                                    <?php if (isset($component)) { $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Delete::resolve(['action' => ''.e(route('media.pemberitaan.destroy', ['id' => $item->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Delete::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $attributes = $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $component = $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
                                                                </div>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__env->endSlot(); ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'media-cetak-dataTable']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
                                    </div>
                                    <div id="media-elektronik-container" style="display: none;">
                                        <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'media-elektronik-dataTable']); ?>
                                            <?php $__env->slot('slotHeading'); ?>

                                                <tr>
                                                    <th scope="col" class="w-25">GAMBAR</th>
                                                    <th scope="col" class="w-35">RESPON</th>
                                                    <th scope="col">JENIS MEDIA</th>
                                                    <?php if(isAllAdmin()): ?>
                                                        <th scope="col" class="text-center">AKSI</th>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php $__env->endSlot(); ?>


                                            <?php $__env->slot('slotBody'); ?>
                                                <?php $__currentLoopData = $pemberitaan_elektronik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $gambar = isFileExists(
                                                            'storage/images/pemberitaan/' . $item->gambar,
                                                            asset('assets/img/dafault/default-bg.png'),
                                                        );
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <img class="rounded"
                                                                src="<?php echo e($gambar); ?>"
                                                                width="170" height="83" alt="">
                                                        </td>
                                                        <td>
                                                            <?php
                                                                $respon = $item->respon;
                                                            ?>
                                                            <span
                                                                class="badge text-uppercase <?php echo e(strtolower($respon) == 'positif'
                                                                    ? 'bg-success'
                                                                    : (strtolower($respon) == 'negatif'
                                                                        ? 'bg-danger'
                                                                        : (strtolower($respon) == 'netral'
                                                                            ? 'bg-primary'
                                                                            : ''))); ?>"><?php echo e($respon); ?>

                                                            </span>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                $jenis = 'Media Elektronik';
                                                            ?>
                                                            <span class="badge text-uppercase bg-progress-more-warning">
                                                                <?php echo e($item->jenis); ?>


                                                            </span>
                                                        </td>
                                                        <?php if(isAllAdmin()): ?>
                                                            <td>
                                                                <div
                                                                    class="aksi d-flex align-items-center justify-content-center">
                                                                    <a class="editClassed" href="##edit" id="edit"
                                                                        data-bs-toggle="modal" data-bs-target="#editModal"
                                                                        onclick="updatePemberitaan(
                                                                        '<?php echo e(route('media.pemberitaan.update', ['id' => $item->id])); ?>',
                                                                        'media elektronik',
                                                                        'positif',
                                                                        '<?php echo e($gambar); ?>'
                                                                    )">
                                                                        <?php if (isset($component)) { $__componentOriginal6a24e45ead027dffc98dad0a673cefeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Edit::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Edit::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $attributes = $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $component = $__componentOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
                                                                    </a>
                                                                    <?php if (isset($component)) { $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Delete::resolve(['action' => ''.e(route('media.pemberitaan.destroy', ['id' => $item->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Delete::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $attributes = $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $component = $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
                                                                </div>
                                                            </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__env->endSlot(); ?>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'media-elektronik-dataTable']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(isAllAdmin()): ?>
        <!-- Modal -->
        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'tambahPemberitaan','action' => ''.e(route('media.pemberitaan.store', ['id' => $rilis->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Jenis','name' => 'jenis','placeholder' => 'Masukkan Jenis'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="media online">Media Online</option>
                        <option value="media cetak">Media Cetak</option>
                        <option value="media elektronik">Media Elektronik</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Respon','name' => 'respon','placeholder' => 'Masukkan Respon'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="netral">Netral</option>
                        <option value="positif">Positif</option>
                        <option value="negatif">Negatif</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                </div>

                <div class="mb-3" id="inputTautanContainer" style="display: none">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['type' => 'url','label' => 'Tautan','name' => 'tautan','placeholder' => 'Masukkan tautan media','isRequired' => '0'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>

                <div class="mb-3" id="inputGambarContainer" style="display: none">
                    <?php if (isset($component)) { $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2 = $attributes; } ?>
<?php $component = App\View\Components\Forms\File::resolve(['name' => 'gambar','label' => 'Gambar','placeholder' => 'Upload Gambar','isRequired' => '0'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\File::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $attributes = $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $component = $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'editModal','action' => ''.e(route('media')).'','isUpdate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="exampleModalLabel">Ubah Data</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Jenis','name' => 'edtJenis','placeholder' => 'Masukkan Jenis'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="media online">Media Online</option>
                        <option value="media cetak">Media Cetak</option>
                        <option value="media elektronik">Media Elektronik</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Respon','name' => 'edtRespon','placeholder' => 'Masukkan Respon'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="netral">Netral</option>
                        <option value="positif">Positif</option>
                        <option value="negatif">Negatif</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                </div>

                <div class="mb-3" id="edtInputTautanContainer" style="display: none">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['type' => 'url','label' => 'Tautan','name' => 'edtTautan','placeholder' => 'Masukkan tautan media','isRequired' => '0'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>


                <div id="edtInputGambarContainer" style="display: none">
                    <div class="mb-3" id="containerGambarLama">
                        <label>Gambar Lama</label> <br>
                        <img id="gambarLama" src="" alt="Gambar lama">
                    </div>
                    <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2 = $attributes; } ?>
<?php $component = App\View\Components\Forms\File::resolve(['name' => 'edtGambar','label' => 'Gambar','placeholder' => 'Upload Gambar','isRequired' => '0'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\File::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $attributes = $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $component = $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        dataTable(5, "#media-online-dataTable")
        dataTable(5, "#media-cetak-dataTable")

        gambarHandler('gambar')
        gambarHandler('edtGambar')

        $("#jenis").on('change', function() {
            var value = $(this).val();

            if (value === 'media online') {
                $("#inputTautanContainer").show();
                $("#inputGambarContainer").hide();
            } else if (value === 'media cetak' || value === 'media elektronik') {
                $("#inputTautanContainer").hide();
                $("#inputGambarContainer").show();
            } else {
                $("#inputTautanContainer").hide();
                $("#inputGambarContainer").hide();
            }
        })

        $("#edtJenis").on('change', function() {
            var value = $(this).val();

            if (value === 'media online') {
                $("#edtInputTautanContainer").show();
                $("#edtInputGambarContainer").hide();
            } else if (value === 'media cetak' || value === 'media elektronik') {
                $("#edtInputTautanContainer").hide();
                $("#edtInputGambarContainer").show();
                $("#containerGambarLama").hide()
            } else {
                $("#edtInputTautanContainer").hide();
                $("#edtInputGambarContainer").hide();
            }
        })

        $(document).ready(function() {
            $("#jenisMedia").on('change', function() {
                var value = $(this).val()

                if (value === 'media cetak') {
                    $("#media-cetak-container").show()
                    $("#media-online-container").hide()
                    $("#media-elektronik-container").hide()
                } else if (value === 'media elektronik') {
                    $("#media-elektronik-container").show()
                    $("#media-cetak-container").hide()
                    $("#media-online-container").hide()
                } else {
                    $("#media-online-container").show()
                    $("#media-elektronik-container").hide()
                    $("#media-cetak-container").hide()
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\media\detail.blade.php ENDPATH**/ ?>