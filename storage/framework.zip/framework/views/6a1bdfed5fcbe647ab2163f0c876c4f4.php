<div class="card berita animate__animated animate__fadeInUp" data-bs-toggle="modal" data-bs-target="#exampleModal"
    <?php echo e($slot); ?>

>
    <div class="card-body">
        <img src="<?php echo e($gambar); ?>" class="card-img-top" alt="Gambar <?php echo e($title); ?>">
        <h5 title="<?php echo e($title); ?>" class="card-title"><?php echo e(limitCharacters($title, 34)); ?></h5>
        <p class="card-text">
            <?php echo limitCharacters($deskripsi, 100); ?> <span>Selengkapnya</span>
        </p>
    </div>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\card\berita-card.blade.php ENDPATH**/ ?>