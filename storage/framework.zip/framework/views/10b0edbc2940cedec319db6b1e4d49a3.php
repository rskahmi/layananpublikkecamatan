    <!DOCTYPE html>
    <html lang="<?php echo e(setlocale(LC_TIME, 'id_ID.UTF-8')); ?>">

    <head>
        <?php echo $__env->make('layout._partials.user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body class="<?php echo $__env->yieldContent('bodyClass'); ?>">
        <?php if (isset($component)) { $__componentOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.svg.background','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.background'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98)): ?>
<?php $attributes = $__attributesOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98; ?>
<?php unset($__attributesOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98)): ?>
<?php $component = $__componentOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98; ?>
<?php unset($__componentOriginal5d5ad8ff89ac0edfe7f7d4dd16e17e98); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.loading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b)): ?>
<?php $attributes = $__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b; ?>
<?php unset($__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b)): ?>
<?php $component = $__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b; ?>
<?php unset($__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b); ?>
<?php endif; ?>
        <!-- Body -->
        <a class="skip-link sr-only" href="#skip-target">Skip to content</a>
        <div class="page-flex">

            <!-- Sidebar -->
            <?php echo $__env->make('layout._partials.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-wrapper">

                <!-- Main nav -->
                <?php echo $__env->make('layout._partials.user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Main -->
                <main class="main users chart-page" id="skip-target">
                    <div class="container-fluid">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </main>

                <!-- Footer -->
                <?php echo $__env->make('layout._partials.user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <?php echo $__env->make('layout._partials.user.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>

    </html>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\user.blade.php ENDPATH**/ ?>