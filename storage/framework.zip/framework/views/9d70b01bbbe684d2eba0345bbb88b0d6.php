<div class="card program-unggulan">
    <img class="card-img-top" src="<?php echo e($gambar); ?>" height="127" width="100%" alt="Card image cap">
    
    <div class="card-body">
        <h5 class="card-title"><?php echo e($title); ?></h5>
        <div class="mb-1 d-flex">
            <div class="limited-text-deskripsi">
                <?php echo limitCharacters($detail, 40); ?>

            </div>
            <?php if(isLimit($detail, 40)): ?>
                <div class="full-text-deskripsi" style="display: none;">
                    <?php echo $detail; ?>

                </div>
                <a class="text-decoration-underline" href="##more" onclick="showMore(this)">More</a>
            <?php endif; ?>
        </div>
        <p class="card-text">
            <b>Alamat :</b> <?php echo e($alamat); ?>

        </p>
        <p class="card-text">
            <b>Telp :</b> <?php echo e($kontak); ?>

        </p>

        <div class="media-sosial d-flex justify-content-end">
            <a target="_blank" href="https://wa.me/<?php echo e($kontak); ?>">
                <?php if (isset($component)) { $__componentOriginal46990e21484b42a40c9bf05aa6ce08b1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal46990e21484b42a40c9bf05aa6ce08b1 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Whatsapp::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.whatsapp'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Whatsapp::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal46990e21484b42a40c9bf05aa6ce08b1)): ?>
<?php $attributes = $__attributesOriginal46990e21484b42a40c9bf05aa6ce08b1; ?>
<?php unset($__attributesOriginal46990e21484b42a40c9bf05aa6ce08b1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal46990e21484b42a40c9bf05aa6ce08b1)): ?>
<?php $component = $__componentOriginal46990e21484b42a40c9bf05aa6ce08b1; ?>
<?php unset($__componentOriginal46990e21484b42a40c9bf05aa6ce08b1); ?>
<?php endif; ?>
            </a>
        </div>
    </div>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\card\program.blade.php ENDPATH**/ ?>