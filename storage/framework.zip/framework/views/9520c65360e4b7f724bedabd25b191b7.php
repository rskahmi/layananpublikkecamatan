<script src="<?php echo e(asset('assets/guest/js/bootstrap.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.all.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<?php if (isset($component)) { $__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sweetalert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sweetalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9)): ?>
<?php $attributes = $__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9; ?>
<?php unset($__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9)): ?>
<?php $component = $__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9; ?>
<?php unset($__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9); ?>
<?php endif; ?>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<script src="<?php echo e(asset('assets/js/globals.js')); ?>"></script>
<script src="<?php echo e(asset('assets/guest/js/customs.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\_partials\guest\scripts.blade.php ENDPATH**/ ?>