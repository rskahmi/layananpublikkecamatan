<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
    <path
        d="M12 0C5.37 0 0 5.37 0 12C0 18.63 5.37 24 12 24C18.63 24 24 18.63 24 12C24 5.37 18.63 0 12 0ZM18 5.34L20.16 7.5L10.5 17.16L5.34 12L7.5 9.84L10.5 12.84L18 5.34Z"
        fill="#65AE38" />
</svg>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\svg\icon\done.blade.php ENDPATH**/ ?>