<svg xmlns="http://www.w3.org/2000/svg" width="25" height="26" viewBox="0 0 25 26" fill="none">
    <path
        d="M16.6668 9.875V20.2917H8.3335V9.875H16.6668ZM15.1043 3.625H9.896L8.85433 4.66667H5.2085V6.75H19.7918V4.66667H16.146L15.1043 3.625ZM18.7502 7.79167H6.25016V20.2917C6.25016 21.4375 7.18766 22.375 8.3335 22.375H16.6668C17.8127 22.375 18.7502 21.4375 18.7502 20.2917V7.79167Z"
        fill="#145EA8" />
</svg>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\svg\icon\trash.blade.php ENDPATH**/ ?>