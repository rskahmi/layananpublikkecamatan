<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none">
    <path
        d="M14.5833 3.5H5.25C4.78587 3.5 4.34075 3.68437 4.01256 4.01256C3.68437 4.34075 3.5 4.78587 3.5 5.25V18.0833C3.5 18.5475 3.68437 18.9926 4.01256 19.3208C4.34075 19.649 4.78587 19.8333 5.25 19.8333H22.75C23.2141 19.8333 23.6592 19.649 23.9874 19.3208C24.3156 18.9926 24.5 18.5475 24.5 18.0833V13.4167M14 19.8333V24.5M17.5 7H24.5M21 3.5V10.5M8.16667 24.5H19.8333"
        stroke="#65AE38" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
</svg>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\svg\icon\computer.blade.php ENDPATH**/ ?>