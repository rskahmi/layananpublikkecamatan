<?php $__env->startSection('title', 'Tentang Pertamina RU II Dumai'); ?>
<?php $__env->startSection('tentang-content'); ?>
    <div class="overview">
        <div class="gambar-overview"></div>
        <p class="text-center">
            Agustiawan, Area Manager Comm, Rell & CSR RU II
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('before-login.tentang.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\tentang\index.blade.php ENDPATH**/ ?>