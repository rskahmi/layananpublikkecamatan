<?php $__env->startSection('headers'); ?>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Dashboard Berkas'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8576646e017181f7c8f40714a073405d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8576646e017181f7c8f40714a073405d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Berkas::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.berkas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Berkas::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $attributes = $__attributesOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__attributesOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $component = $__componentOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__componentOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xxl-7 mb-2 mb-lg-0">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Proposal Masuk','color' => 'blue','value' => ''.e(formatRibuan($total_berkas)).'','id' => 'totalProposal','footer' => 'dari Pengajuan di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php if (isset($component)) { $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Signin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.signin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Signin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $attributes = $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $component = $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Surat Masuk','color' => 'blue','value' => ''.e(formatRibuan($total_surat)).'','id' => 'totalSurat','footer' => 'dari Pengajuan di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Signin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.signin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Signin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $attributes = $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $component = $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Undangan Masuk','color' => 'blue','value' => ''.e(formatRibuan($total_undangan)).'','id' => 'totalUndangan','footer' => 'dari Pengajuan di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Signin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.signin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Signin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $attributes = $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $component = $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Proposal Dibantu','color' => 'green','value' => ''.e(formatRibuan($jumlah_status_verifikasi)).'','id' => 'totalProposalBantu','footer' => 'dari Pengajuan di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Done::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.done'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Done::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d)): ?>
<?php $attributes = $__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d; ?>
<?php unset($__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d)): ?>
<?php $component = $__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d; ?>
<?php unset($__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Proposal Belum Diverifikasi','color' => 'yellow','value' => ''.e(formatRibuan($jumlah_status_proses)).'','id' => 'totalPengajuanProses','footer' => 'dari Pengajuan di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.svg.icon.program-yellow','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.program-yellow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb)): ?>
<?php $attributes = $__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb; ?>
<?php unset($__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb)): ?>
<?php $component = $__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb; ?>
<?php unset($__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Proposal Ditolak','color' => 'red','value' => ''.e(formatRibuan($jumlah_status_tolak)).'','id' => 'totalProposalTolak','footer' => 'dari Pengajuan di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal457006f680e9a5dd31c5d9dcb59f7b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal457006f680e9a5dd31c5d9dcb59f7b04 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Close::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.close'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Close::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal457006f680e9a5dd31c5d9dcb59f7b04)): ?>
<?php $attributes = $__attributesOriginal457006f680e9a5dd31c5d9dcb59f7b04; ?>
<?php unset($__attributesOriginal457006f680e9a5dd31c5d9dcb59f7b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal457006f680e9a5dd31c5d9dcb59f7b04)): ?>
<?php $component = $__componentOriginal457006f680e9a5dd31c5d9dcb59f7b04; ?>
<?php unset($__componentOriginal457006f680e9a5dd31c5d9dcb59f7b04); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Total Anggaran Proposal Dibantu','color' => 'green','value' => ''.e(formatRupiah($total_anggaran)).'','id' => 'totalAnggaranBantu'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal4efc99ff666154d0a4a6dc46cb9759c1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4efc99ff666154d0a4a6dc46cb9759c1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.svg.icon.currency-green','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.currency-green'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4efc99ff666154d0a4a6dc46cb9759c1)): ?>
<?php $attributes = $__attributesOriginal4efc99ff666154d0a4a6dc46cb9759c1; ?>
<?php unset($__attributesOriginal4efc99ff666154d0a4a6dc46cb9759c1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4efc99ff666154d0a4a6dc46cb9759c1)): ?>
<?php $component = $__componentOriginal4efc99ff666154d0a4a6dc46cb9759c1; ?>
<?php unset($__componentOriginal4efc99ff666154d0a4a6dc46cb9759c1); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Stakeholder yang Dibantu','color' => 'green','value' => ''.e(formatRibuan($jumlah_stakeholder)).'','id' => 'totalStakeholderBantu'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Program::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.program'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Program::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $attributes = $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $component = $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xxl-5 mb-2 mb-lg-0">
            <div class="row" style="margin-left: 0;">
                <div class="col-12 charts">
                    <h4>Pengajuan Berdasarkan Stakeholder</h4>
                    <div class="container-fluid">
                        <canvas id="barChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xxl-7 mb-2 mb-lg-0">
            <div class="card table">
                <div class="card-header">
                    <h4>Pengajuan Berkas</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php $__env->slot('slotHeading'); ?>
                            <tr>
                                <th scope="col">BERKAS</th>
                                <th scope="col">BATAS KONFIRMASI</th>
                                <th scope="col">STATUS</th>
                                <th scope="col">AKSI</th>
                            </tr>
                        <?php $__env->endSlot(); ?>


                        <?php $__env->slot('slotBody'); ?>
                            <?php $__currentLoopData = $berkas_proses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="w-50">
                                        <h6><?php echo e($item['nama_berkas']); ?></h6>
                                    </td>
                                    <td>
                                        <?php echo e(format_dfy($item['batas_konfirmasi'])); ?>

                                    </td>
                                    <td>
                                        <span class="badge <?php echo e(strtolower($item['status']) == 'diajukan' ? 'bg-warning-subtle text-dark' : 'bg-warning'); ?> text-capitalize"><?php echo e($item['status']); ?></span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('berkas.detail', ['id' => $item['id']])); ?>">
                                            <?php if (isset($component)) { $__componentOriginal334a1e8d53b1004ac9cb270596a849ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Info::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Info::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $attributes = $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $component = $__componentOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
        </div>
        <div class="col-5 col-12 col-sm-12 col-md-12 col-lg-5 col-xxl-5 mb-2 mb-lg-0">
            <div class="charts">
                <h4>Persentase Proposal yang Sudah Diverifikasi</h4>
                <div class="container-fluid">
                    <canvas id="tjslPieChart" height="211" width="211"></canvas>
                    <div class="label d-flex justify-content-center mt-3">
                        <span>
                            <span class="icon positif"></span>&nbsp;<?php echo e($jumlah_status_verifikasi); ?> Dibantu
                        </span>
                        <span>
                            <span class="icon netral"></span>&nbsp;<?php echo e($jumlah_status_tolak); ?> Ditolak
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chartjs-plugin-datalabels/2.0.0/chartjs-plugin-datalabels.min.js">
    </script>

    <script>
        dataTable(2)

        const labels = <?php echo json_encode($labels, 15, 512) ?>;
        const datax = <?php echo json_encode($datax, 15, 512) ?>;

        const data = {
            labels: labels,
            datasets: [{
                label: 'Data',
                backgroundColor: '#34B53A',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1,
                borderRadius: 40,
                barThickness: 6,
                data: datax,
            }]
        };

        const config = {
            type: 'bar',
            data: data,
            options: {
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            borderWidth: 0,
                            font: {
                                size: 10
                            }
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            drawBorder: false,
                        },
                        ticks: {
                            font: {
                                size: 10
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        };

        const tjslLabels = ["Ditolak", "Dibantu"]
        const tjslData = [<?php echo $jumlah_status_tolak; ?>, <?php echo $jumlah_status_verifikasi; ?>]
        console.log(tjslData)


        pie("tjslPieChart", tjslLabels, tjslData)


        // Create the chart
        var myChart = new Chart(
            document.getElementById('barChart'),
            config
        );

        document.addEventListener('DOMContentLoaded', function() {
            Echo.channel('channel-dashboard-berkas')
                .listen('DashboardBerkasEvent', (e) => {
                    var berkas = e.data

                    if (tjsl.hasOwnProperty('deleted_at')) {
                        unsetSummary("#totalProposal")
                        unsetSummary("#totalSurat")
                        unsetSummary("#totalUndangan")
                        unsetSummary("#totalProposalProses");
                        unsetSummary("#totalProposalVerifikasi");
                        unsetSummary("#totalProposalTolak");
                        unsetSummary("#totalAnggaranBantu");
                        unsetSummary("#totalStakeholderBantu");
                        unsetSummary("#totalBerkas");
                    } else {
                        setSummary("#totalProposal")
                        setSummary("#totalSurat")
                        setSummary("#totalUndangan")
                        setSummary("#totalProposalProses");
                        setSummary("#totalProposalVerifikasi");
                        setSummary("#totalProposalTolak");
                        setSummary("#totalAnggaranBantu");
                        setSummary("#totalStakeholderBantu");
                        setSummary("#totalBerkas");
                    }
                })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\berkas\dashboard.blade.php ENDPATH**/ ?>