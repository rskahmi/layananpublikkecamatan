<aside class="sidebar">
    <div class="sidebar-start">
        <div class="sidebar-head">
            <a href="/" class="logo-wrapper" title="Home">
                <span class="sr-only">Home</span>
                <img src="<?php echo e(asset('assets/img/logo/logo-simpro-csr.png')); ?>" alt="Logo <?php echo e(config('app.name')); ?>"
                    width="93" height="93">
            </a>
            <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
                <span class="sr-only">Toggle menu</span>
                <span class="icon menu-toggle" aria-hidden="true"></span>
            </button>
        </div>
        <div class="sidebar-body">
            <ul class="sidebar-body-menu">
                <li>
                    <a class="<?php echo e((isRouteActive('resume') ? 'active' : '')); ?>" href="<?php echo e(route('resume')); ?>">
                        <span class="icon resume" aria-hidden="true"></span>
                        Resume
                    </a>
                </li>
                <li>
                    <a class="show-cat-btn <?php echo e((isRouteActive('berkas') ? 'reactive' : (isRouteActive('berkas.pengajuan') ? 'reactive' : (isRouteActive('berkas.detail') ? 'reactive' : '' )))); ?>" href="##">
                        <span class="icon berkas" aria-hidden="true"></span>
                        Berkas
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Berkas</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a class="<?php echo e((isRouteActive('berkas') ? 'active' : '')); ?>" href="<?php echo e(route('berkas')); ?>">Dashboard</a>
                        </li>
                        <li>
                            <a class="<?php echo e((isRouteActive('berkas.pengajuan') ? 'active' : (isRouteActive('berkas.detail') ? 'active' : ''))); ?>" href="<?php echo e(route('berkas.pengajuan')); ?>">Pengajuan</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a class="show-cat-btn <?php echo e((isRouteActive('media') ? 'reactive' : (isRouteActive('media.monitoring') ? 'reactive' : (isRouteActive('media.detail') ? 'reactive' : '')))); ?>" href="##">
                        <span class="icon media" aria-hidden="true">
                        </span>
                        Rilis
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Rilis</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a class="<?php echo e((isRouteActive('media') ? 'active' : '')); ?>" href="<?php echo e(route('media')); ?>">Dashboard</a>
                        </li>
                        <li>
                            <a class="<?php echo e((isRouteActive('media.monitoring') ? 'active' : (isRouteActive('media.detail') ? 'active' : ''))); ?>" href="<?php echo e(route('media.monitoring')); ?>">Monitoring</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a class="show-cat-btn <?php echo e((isRouteActive('tjsl') ? 'reactive' : (isRouteActive('tjsl.monitoring') ? 'reactive' : (isRouteActive('tjsl.anggaran') ? 'reactive' : (isRouteActive('tjsl.detail') ? 'reactive' : ''))))); ?>" href="##">
                        <span class="icon tjsl">
                        </span>
                        TJSL
                        <span class="category__btn transparent-btn" title="Open list">
                            <span class="sr-only">Program</span>
                            <span class="icon arrow-down" aria-hidden="true"></span>
                        </span>
                    </a>
                    <ul class="cat-sub-menu">
                        <li>
                            <a class="<?php echo e((isRouteActive('tjsl') ? 'active' : '')); ?>" href="<?php echo e(route('tjsl')); ?>">Dashboard</a>
                        </li>
                        <li>
                            <a class="<?php echo e((isRouteActive('tjsl.monitoring') ? 'active' : (isRouteActive('tjsl.detail') ? 'active' : ''))); ?>" href="<?php echo e(route('tjsl.monitoring')); ?>">Monitoring</a>
                        </li>
                        <li>
                            <a class="<?php echo e((isRouteActive('tjsl.anggaran') ? 'active' : '')); ?>" href="<?php echo e(route('tjsl.anggaran')); ?>">Anggaran</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="<?php echo e((isRouteActive('program-unggulan') ? 'active' : '')); ?>" href="<?php echo e(route('program-unggulan')); ?>">
                        <span class="icon program-unggulan" aria-hidden="true">
                        </span>
                        Program
                    </a>
                </li>
                <li>
                    <a class="<?php echo e((isRouteActive('iso') ? 'active' : '')); ?>" href="<?php echo e(route('iso')); ?>">
                        <span class="icon iso" aria-hidden="true">
                        </span>
                        TKO
                    </a>
                </li>
                <?php if(isManager()): ?>
                    <li>
                        <a class="<?php echo e((isRouteActive('user') ? 'active' : '')); ?>" href="<?php echo e(route('user')); ?>">
                            <span class="icon pengguna" aria-hidden="true"></span>
                            </span>
                            Pengguna
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
    <div class="sidebar-footer">
        <ul class="sidebar-body-menu">
            <li>
                <a href="<?php echo e(route('logout')); ?>" id="btn-logout">
                    <span class="icon logout" aria-hidden="true"></span>
                    Logout
                </a>
            </li>
        </ul>
    </div>
</aside>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\_partials\user\sidebar.blade.php ENDPATH**/ ?>