<script src="<?php echo e(asset('assets/user/plugins/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/plugins/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/script.js')); ?>"></script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
</script>


<script src="<?php echo e(asset('assets/js/datepicker.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.all.min.js"></script>
<?php if (isset($component)) { $__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sweetalert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sweetalert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9)): ?>
<?php $attributes = $__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9; ?>
<?php unset($__attributesOriginalc198bc3297ddb8aa34c13c9e1dde42d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9)): ?>
<?php $component = $__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9; ?>
<?php unset($__componentOriginalc198bc3297ddb8aa34c13c9e1dde42d9); ?>
<?php endif; ?>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
<script src="<?php echo e(asset('assets/user/js/customs.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/globals.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\_partials\user\scripts.blade.php ENDPATH**/ ?>