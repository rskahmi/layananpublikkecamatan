<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Surat Balasan Terhadap <?php echo e($nama); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <style>
        * {
            margin: 0;
            padding: 0;
        }

        html,
        body {
            width: 210mm;
            height: 297mm;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .content {
            width: 100%;
            height: 100%;
            padding: 20px 58px 0 74px;
            box-sizing: border-box;
            background: rebeccapurple;
        }

        .content,
        table {
            color: var(--Dark-1-Dark, #202020);
            font-family: "Inter", sans-serif;
            font-size: 12px;
            font-style: normal;
            font-weight: 500;
        }

        .header {
            text-align: right;
        }

        .header img {
            height: 60mm;
            width: 169mm;
        }

        tr td {
            padding: 5px;
        }

        span.bolder {
            font-weight: bold;
        }

        .mt-0 {
            margin-top: 0px !important;
        }

        .mt-1 {
            margin-top: 4px !important;
        }

        .mt-2 {
            margin-top: 8px !important;
        }

        .mt-3 {
            margin-top: 16px !important;
        }

        .mt-4 {
            margin-top: 24px !important;
        }

        .mt-5 {
            margin-top: 48px !important;
        }
    </style>
</head>

<body>

    <div class="content">
        <div class="header">
            <img style="height: 150px; width: 300px;"
                src="D:\JRFS\Self\Project\simpro-csr\public\assets\img\dafault\File.png" alt="Surat Balasan <?php echo e($nama); ?>">
        </div>
        <div class="body">
            <div class="date">
                <div>Dumai, <?php echo e($tanggal_sekarang); ?></div>
                <div>No. <?php echo e($no_surat); ?></div>
            </div>
            <div class="perihal mt-3">
                <p>Perihal &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Pengajuan proposal <?php echo e(removeProposalWord($nama)); ?></p>
            </div>
            <div class="greeting mt-2">
                <div>Yang terhormat</div>
                <div>Bapak/Ibu <?php echo e($pemohon); ?></div>
                <div>Di -</div>
                <div>Tempat</div>
            </div>
            <div class="pembuka mt-4">
                <p>Dengan Hormat,</p>
                <p class="text-justify">
                    Sehubungan dengan pengajuan proposal <?php echo e(removeProposalWord($nama)); ?> No. <span
                    class="bolder"><?php echo e($no_surat_proposal); ?></span> pada tanggal <?php echo e($tanggal_masuk); ?> perihal permohonan dana, sebelumnya kami mengucapkan terimakasih atas perhatian saudara kepada PT Kilang Pertamina Internasional Unit II Dumai.
                </p>
                <p class="text-justify">Berkaitan dengan permohonan bantuan sebagaimana termuat dalam surat tersebut, kami memutuskan untuk <span class="bolder">menerima</span> pengajuan tersebut dengan rincian sebagai berikut:</p>
            </div>
            <div class="detail ms-5">
                <table>
                    <tr>
                        <td>Surat</td>
                        <td>:</td>
                        <td><?php echo e($nama); ?></td>
                    </tr>
                    <tr>
                        <td>Tanggal Masuk</td>
                        <td>:</td>
                        <td><?php echo e($tanggal_masuk); ?></td>
                    </tr>
                    <tr>
                        <td>Nama Pemohon</td>
                        <td>:</td>
                        <td><?php echo e($pemohon); ?></td>
                    </tr>
                    <tr>
                        <td>Anggaran</td>
                        <td>:</td>
                        <td><?php echo e($anggaran); ?></td>
                    </tr>
                </table>
            </div>
            <div class="penutup mt-3">
                <p class="text-justify">Berdasarkan hal tersebut, saudara diminta untuk memenuhi beberapa dan mengirim persyaratan berikut ini ke alamat email <span class="bolder"><?php echo e(config('services.company.email')); ?></span> berupa:</p>
                <ol>
                    <li>Foto Copy KTP</li>
                    <li>KWITANSI</li>
                </ol>

                <p class="mt-1 text-justify">
                    Perlu kami informasikan bahwa semua biaya selama mengikuti kerja praktek di PT.Kilang Pertamina
                    Internasional Refinery Unit II Dumai menjadi beban yang bersangkutan.
                    Demikian disampaikan, atas perhatian dan kerjasamanya kami ucapkan terima kasih.
                </p>
            </div>
            <div class="ttd mt-5">
                <p>Area Manager Comm & Relation Sumbagut</p>
                <p class="pt-5">Agustiawan</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\pdf\surat-persetujuan.blade.php ENDPATH**/ ?>