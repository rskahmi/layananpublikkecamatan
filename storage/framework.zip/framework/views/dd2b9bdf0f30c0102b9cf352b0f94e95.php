<div class="card developer animate__animated animate__fadeInUp">
    <img src="<?php echo e($gambar); ?>" class="card-img-top" alt="Foto <?php echo e($nama); ?>">
    <div class="card-body">
        <h5 class="card-title text-center"><?php echo e($nama); ?></h5>
        <p class="card-text text-center">
            <?php echo e($role); ?>

        </p>
    </div>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\card\developer.blade.php ENDPATH**/ ?>