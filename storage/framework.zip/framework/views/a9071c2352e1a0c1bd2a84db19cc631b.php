<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
    <div class="login animate__animated animate__fadeInRight">
        <h1>Sign In</h1>
        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="col-12">
                <div class="mb-3 mb-md-4 mb-lg-3">
                    <i class="envelope icon"></i>
                    <input type="email" name ="email" class="form-control" placeholder="Email Address">
                </div>
            </div>
            <div class="col-12">
                <div class="mb-3 mb-md-4 mb-lg-3">
                    <i class="lock icon"></i>
                    <input type="password" name="password" class="form-control" placeholder="Password">
                </div>
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary w-100">Sign In</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest-right-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\authentication\login.blade.php ENDPATH**/ ?>