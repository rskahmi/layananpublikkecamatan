<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layout._partials.guest.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="auth">
    <?php if (isset($component)) { $__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.loading','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.loading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b)): ?>
<?php $attributes = $__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b; ?>
<?php unset($__attributesOriginal4a02f92a72c1efd3d66ce3aefa16ea1b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b)): ?>
<?php $component = $__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b; ?>
<?php unset($__componentOriginal4a02f92a72c1efd3d66ce3aefa16ea1b); ?>
<?php endif; ?>

    <div class="auth-container">
        <div class="row contain">
            <div class="left col-0 col-lg-5 col-xl-5 col-xxl-6 d-flex align-items-center justify-content-center">
                <img
                    src="<?php echo e(asset('assets/img/logo/logo-simpro-csr.png')); ?>" alt="Logo <?php echo e(config('app.name')); ?>"
                    width="406" height="406" class="animate__animated animate__fadeInLeft">
            </div>
            <div class="right col-12 col-sm-12 col-md-12 col-lg-7 col-xl-7 col-xxl-6 bg-gray">
                <div class="row">
                    <div class="body">
                        <div class="col-12 top">
                            <?php echo $__env->make('layout._partials.guest.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <main id="skip-target">
                                <?php echo $__env->yieldContent('content'); ?>
                            </main>
                        </div>
                        <div class="col-12">
                            <?php echo $__env->make('layout._partials.guest.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <?php echo $__env->make('layout._partials.guest.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\guest-right-navbar.blade.php ENDPATH**/ ?>