<?php $__env->startSection('title', 'Tentang Pertamina RU II Dumai'); ?>
<?php $__env->startSection('tentang-content'); ?>
    <div class="produk">
        <h3 class="tentang-title">Produk Yang Dihasilkan RU II Dumai</h3>
        <h4 class="tentang-title mt-3">BBM</h4>
        <div class="row">
            <div class="col-6 col-md-4 col-lg-3 mb-4">
                <?php if (isset($component)) { $__componentOriginala387e84c4c9102e87dd88dff89e2332a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala387e84c4c9102e87dd88dff89e2332a = $attributes; } ?>
<?php $component = App\View\Components\Card\Produk::resolve(['source' => ''.e(asset('assets/img/dafault/produk/pertalite.png')).'','title' => 'Pertalite'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.produk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Produk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $attributes = $__attributesOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $component = $__componentOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__componentOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
            </div>
            <div class="col-6 col-md-4 col-lg-3 mb-4">
                <?php if (isset($component)) { $__componentOriginala387e84c4c9102e87dd88dff89e2332a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala387e84c4c9102e87dd88dff89e2332a = $attributes; } ?>
<?php $component = App\View\Components\Card\Produk::resolve(['source' => ''.e(asset('assets/img/dafault/produk/pertamax.png')).'','title' => 'Pertamax'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.produk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Produk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $attributes = $__attributesOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $component = $__componentOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__componentOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
            </div>
            <div class="col-6 col-md-4 col-lg-3 mb-4">
                <?php if (isset($component)) { $__componentOriginala387e84c4c9102e87dd88dff89e2332a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala387e84c4c9102e87dd88dff89e2332a = $attributes; } ?>
<?php $component = App\View\Components\Card\Produk::resolve(['source' => ''.e(asset('assets/img/dafault/produk/pertamax-turbo.png')).'','title' => 'Pertamax Turbo'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.produk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Produk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $attributes = $__attributesOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $component = $__componentOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__componentOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
            </div>
            <div class="col-6 col-md-4 col-lg-3 mb-4 mt-0">
                <?php if (isset($component)) { $__componentOriginala387e84c4c9102e87dd88dff89e2332a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala387e84c4c9102e87dd88dff89e2332a = $attributes; } ?>
<?php $component = App\View\Components\Card\Produk::resolve(['source' => ''.e(asset('assets/img/dafault/produk/pertadex.png')).'','title' => 'Pertamina DEX'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.produk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Produk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $attributes = $__attributesOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $component = $__componentOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__componentOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
            </div>
            <div class="col-6 col-md-4 col-lg-3 mb-4 mt-0 mt-lg-3">
                <?php if (isset($component)) { $__componentOriginala387e84c4c9102e87dd88dff89e2332a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala387e84c4c9102e87dd88dff89e2332a = $attributes; } ?>
<?php $component = App\View\Components\Card\Produk::resolve(['source' => ''.e(asset('assets/img/dafault/produk/biosolar.png')).'','title' => 'Biosolar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.produk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Produk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $attributes = $__attributesOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $component = $__componentOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__componentOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
            </div>
            <div class="col-6 col-md-4 col-lg-3 mb-4 mt-lg-3">
                <?php if (isset($component)) { $__componentOriginala387e84c4c9102e87dd88dff89e2332a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala387e84c4c9102e87dd88dff89e2332a = $attributes; } ?>
<?php $component = App\View\Components\Card\Produk::resolve(['source' => ''.e(asset('assets/img/dafault/produk/dexlite.png')).'','title' => 'Dexlite'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.produk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Produk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $attributes = $__attributesOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $component = $__componentOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__componentOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
            </div>
            <div class="col-6 col-md-4 col-lg-3 mb-4 mt-0 mt-lg-3">
                <?php if (isset($component)) { $__componentOriginala387e84c4c9102e87dd88dff89e2332a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala387e84c4c9102e87dd88dff89e2332a = $attributes; } ?>
<?php $component = App\View\Components\Card\Produk::resolve(['source' => ''.e(asset('assets/img/dafault/produk/aviation.png')).'','title' => 'Aviation'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.produk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Produk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $attributes = $__attributesOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__attributesOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala387e84c4c9102e87dd88dff89e2332a)): ?>
<?php $component = $__componentOriginala387e84c4c9102e87dd88dff89e2332a; ?>
<?php unset($__componentOriginala387e84c4c9102e87dd88dff89e2332a); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('before-login.tentang.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\tentang\produk.blade.php ENDPATH**/ ?>