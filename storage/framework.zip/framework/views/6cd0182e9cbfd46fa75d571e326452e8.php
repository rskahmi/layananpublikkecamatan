<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<meta name="og:site_name" content="<?php echo e(config('app.url')); ?>">
<meta name="og:title" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?>">
<meta name="og:image" content="<?php echo e(asset('assets/img/logo/logo-simpro-csr.svg')); ?>">
<meta name="og:description" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?> <?php echo e(config('app.description')); ?>">


<meta name="title" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?>">
<meta name="description" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?> <?php echo e(config('app.description')); ?>">
<meta name="image" content="<?php echo e(asset('assets/img/logo/logo-simpro-csr.svg')); ?>">
<meta name="keywords" content="laundry">
<meta name="author" content="<?php echo e(config('app.url')); ?>">

<title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?> <?php echo e(config('app.description')); ?></title>

<link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&Lato:ital,wght@0,600&display=swap"
    rel="stylesheet">
<link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
<link rel="stylesheet" href="<?php echo e(asset('assets/user/css/style.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/user/css/customs.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/datepicker.css')); ?>">

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.2.0/classic/ckeditor.js"></script>

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">

<link
    rel="stylesheet" type="text/css"
    href="//cdn.jsdelivr.net/gh/loadingio/ldbutton@latest/dist/index.min.css"
/>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.all.min.js"></script>
<?php echo $__env->yieldContent('headers'); ?>

<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\_partials\user\header.blade.php ENDPATH**/ ?>