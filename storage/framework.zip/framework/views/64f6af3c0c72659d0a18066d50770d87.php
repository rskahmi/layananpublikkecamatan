<?php if (isset($component)) { $__componentOriginal89b295b0763c93abe0143426334eb5d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal89b295b0763c93abe0143426334eb5d6 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Label::resolve(['name' => ''.e($name).'','isRequired' => ''.e($isRequired).'','label' => ''.e($label).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Label::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal89b295b0763c93abe0143426334eb5d6)): ?>
<?php $attributes = $__attributesOriginal89b295b0763c93abe0143426334eb5d6; ?>
<?php unset($__attributesOriginal89b295b0763c93abe0143426334eb5d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal89b295b0763c93abe0143426334eb5d6)): ?>
<?php $component = $__componentOriginal89b295b0763c93abe0143426334eb5d6; ?>
<?php unset($__componentOriginal89b295b0763c93abe0143426334eb5d6); ?>
<?php endif; ?>
<div class="custom-file-input">
    <div class="icon">
        <?php if (isset($component)) { $__componentOriginalef399086fd1866463549dd90877a7348 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef399086fd1866463549dd90877a7348 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Cloud::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.cloud'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Cloud::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef399086fd1866463549dd90877a7348)): ?>
<?php $attributes = $__attributesOriginalef399086fd1866463549dd90877a7348; ?>
<?php unset($__attributesOriginalef399086fd1866463549dd90877a7348); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef399086fd1866463549dd90877a7348)): ?>
<?php $component = $__componentOriginalef399086fd1866463549dd90877a7348; ?>
<?php unset($__componentOriginalef399086fd1866463549dd90877a7348); ?>
<?php endif; ?>
    </div>
    <input
        type="file"
        id="<?php echo e($name); ?>"
        name="<?php echo e($name); ?>"
        style="display: none;"
        >
    <label
        id="fileLabel"
        class="<?php echo e($name); ?> text-break"
        for="<?php echo e($name); ?>">
        <?php echo e($placeholder); ?>

    </label>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\forms\file.blade.php ENDPATH**/ ?>