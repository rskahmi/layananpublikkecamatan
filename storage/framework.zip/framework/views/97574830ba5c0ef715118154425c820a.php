<div id="page-loader">
    <div class="loader"></div>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\layout\loading.blade.php ENDPATH**/ ?>