<a href="##delete" class="btnDeleteData d-flex align-items-center justify-content-center">
    <form action="<?php echo e($action); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <?php if (isset($component)) { $__componentOriginal075b0c58f0cc9c32313fe68c831e84ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal075b0c58f0cc9c32313fe68c831e84ad = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Trash::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Trash::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal075b0c58f0cc9c32313fe68c831e84ad)): ?>
<?php $attributes = $__attributesOriginal075b0c58f0cc9c32313fe68c831e84ad; ?>
<?php unset($__attributesOriginal075b0c58f0cc9c32313fe68c831e84ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal075b0c58f0cc9c32313fe68c831e84ad)): ?>
<?php $component = $__componentOriginal075b0c58f0cc9c32313fe68c831e84ad; ?>
<?php unset($__componentOriginal075b0c58f0cc9c32313fe68c831e84ad); ?>
<?php endif; ?>
    </form>
</a>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\layout\delete.blade.php ENDPATH**/ ?>