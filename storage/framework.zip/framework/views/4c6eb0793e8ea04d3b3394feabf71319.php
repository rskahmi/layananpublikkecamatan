    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <meta name="og:site_name" content="<?php echo e(config('app.url')); ?>">
    <meta name="og:title" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?>">
    <meta name="og:image" content="<?php echo e(asset('assets/img/logo/logo-simpro-csr.svg')); ?>">
    <meta name="og:description" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?> <?php echo e(config('app.description')); ?>">

    
    <meta name="title" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?>">
    <meta name="description" content="<?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?> <?php echo e(config('app.description')); ?>">
    <meta name="image" content="<?php echo e(asset('assets/img/logo/logo-simpro-csr.svg')); ?>">
    <meta name="keywords" content="laundry">
    <meta name="author" content="<?php echo e(config('app.url')); ?>">

<title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?> <?php echo e(config('app.description')); ?></title>

<link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\_partials\meta.blade.php ENDPATH**/ ?>