<?php $__env->startSection('bodyClass', 'body-tentang'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-header">
            <h1>Tentang Kami</h1>
        </div>
        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-5 col-xl-4 col-xxl-4">
                <ul class="nav-tentang">
                    <li>
                        <a class="btn w-100 <?php echo e(isRouteActive('tentang') ? 'active' : ''); ?>" href="<?php echo e(route('tentang')); ?>">
                            Sekilas Pertamina RU II Dumai
                        </a>
                    </li>
                    <li>
                        <a class="btn w-100 <?php echo e(isRouteActive('tentang.sejarah') ? 'active' : ''); ?>" href="<?php echo e(route('tentang.sejarah')); ?>">
                            Sejarah Pertamina RU II Dumai
                        </a>
                    </li>
                    <li>
                        <a class="btn w-100 <?php echo e(isRouteActive('tentang.visi-misi') ? 'active' : ''); ?>" href="<?php echo e(route('tentang.visi-misi')); ?>">
                            Visi & Misi
                        </a>
                    </li>
                    <li>
                        <a class="btn w-100 <?php echo e(isRouteActive('tentang.produk') ? 'active' : ''); ?>" href="<?php echo e(route('tentang.produk')); ?>">
                            Produk Yang Dihasilkan
                        </a>
                    </li>
                    <li>
                        <a class="btn w-100 <?php echo e(isRouteActive('tentang.program') ? 'active' : ''); ?>" href="<?php echo e(route('tentang.program')); ?>">
                            Program Unggulan
                        </a>
                    </li>
                    <li>
                        <a class="btn w-100 <?php echo e(isRouteActive('tentang.struktur') ? 'active' : ''); ?>" href="<?php echo e(route('tentang.struktur')); ?>">
                            Struktur Group Comm, Rel & CSR RU II Dumai
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-7 col-xl-8 col-xxl-8 mt-3 mt-lg-0">
                <div class="tentang-content">
                    <?php echo $__env->yieldContent('tentang-content'); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\tentang\layout.blade.php ENDPATH**/ ?>