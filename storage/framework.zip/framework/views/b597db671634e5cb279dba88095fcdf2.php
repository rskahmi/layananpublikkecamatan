<?php $__env->startSection('headers'); ?>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Pengguna'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Tjsl::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.tjsl'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Tjsl::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $attributes = $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $component = $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
    <div class="row">
        <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Total Akun','value' => ''.e(formatRibuan($total_akun)).'','footer' => 'dari Seluruh Pengguna','id' => 'allUsers'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal627405b9895dc38d0e8df2fc6ba7b011 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal627405b9895dc38d0e8df2fc6ba7b011 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Users::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.users'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Users::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal627405b9895dc38d0e8df2fc6ba7b011)): ?>
<?php $attributes = $__attributesOriginal627405b9895dc38d0e8df2fc6ba7b011; ?>
<?php unset($__attributesOriginal627405b9895dc38d0e8df2fc6ba7b011); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal627405b9895dc38d0e8df2fc6ba7b011)): ?>
<?php $component = $__componentOriginal627405b9895dc38d0e8df2fc6ba7b011; ?>
<?php unset($__componentOriginal627405b9895dc38d0e8df2fc6ba7b011); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Akun Manager','color' => 'red','value' => ''.e(formatRibuan($total_manager)).'','footer' => 'dari Seluruh Pengguna','id' => 'akunManager'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal9d3c78ec94ed45db138213cec8c701b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d3c78ec94ed45db138213cec8c701b6 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Manager::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.manager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Manager::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d3c78ec94ed45db138213cec8c701b6)): ?>
<?php $attributes = $__attributesOriginal9d3c78ec94ed45db138213cec8c701b6; ?>
<?php unset($__attributesOriginal9d3c78ec94ed45db138213cec8c701b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d3c78ec94ed45db138213cec8c701b6)): ?>
<?php $component = $__componentOriginal9d3c78ec94ed45db138213cec8c701b6; ?>
<?php unset($__componentOriginal9d3c78ec94ed45db138213cec8c701b6); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Akun Admin','color' => 'blue','value' => ''.e(formatRibuan($total_admin)).'','footer' => 'dari Seluruh Pengguna','id' => 'akunAdmin'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal702d2a2e015944b18189091b2940a101 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal702d2a2e015944b18189091b2940a101 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Admin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal702d2a2e015944b18189091b2940a101)): ?>
<?php $attributes = $__attributesOriginal702d2a2e015944b18189091b2940a101; ?>
<?php unset($__attributesOriginal702d2a2e015944b18189091b2940a101); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal702d2a2e015944b18189091b2940a101)): ?>
<?php $component = $__componentOriginal702d2a2e015944b18189091b2940a101; ?>
<?php unset($__componentOriginal702d2a2e015944b18189091b2940a101); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="animate__animated animate__fadeInUp">
        <div class="card table mt-2 mt-lg-3">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-6">
                        <h4>Daftar List Akun</h4>
                    </div>
                    <div class="col-6 d-flex justify-content-end gap-2">
                        <?php if (isset($component)) { $__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6)): ?>
<?php $attributes = $__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6; ?>
<?php unset($__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6)): ?>
<?php $component = $__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6; ?>
<?php unset($__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6); ?>
<?php endif; ?>
                        <?php if(isManager()): ?>
                            <button class="btn btn-primary text-capitalize" data-bs-toggle="modal" data-bs-target="#tambahUser">
                                <?php if (isset($component)) { $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Addfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.addfile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Addfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $attributes = $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $component = $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
                                Tambah User
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php $__env->slot('slotHeading'); ?>
                        <tr>
                            <th scope="col">NAMA</th>
                            <th scope="col">EMAIL</th>
                            <th scope="col">DEPARTEMEN</th>
                            <th scope="col">NIP</th>
                            <th scope="col">ROLE</th>
                        </tr>
                    <?php $__env->endSlot(); ?>

                    <?php $__env->slot('slotBody'); ?>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($item->nama); ?>

                            </td>
                            <td>
                                <?php echo e($item->email); ?>

                            </td>
                            <td>
                                <?php echo e($item->departemen); ?>

                            </td>
                            <td>
                                <?php echo e($item->nip); ?>

                            </td>
                            <td>
                                <?php echo e(roles($item->role )); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
    </div>

    <!-- Modal -->
    <?php if(isManager()): ?>
        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['action' => ''.e(route('user.store')).'','id' => 'tambahUser'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="exampleModalLabel">Tambah User</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nama Lengkap','name' => 'nama','placeholder' => 'Masukkan Nama Lengkap'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Email','name' => 'email','type' => 'email','placeholder' => 'Masukkan Email'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Departemen','name' => 'departemen','placeholder' => 'Masukkan Departement'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nomor Pegawai','type' => 'number','name' => 'nip','placeholder' => 'Masukkan Nomor Pegawai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Role Akses','name' => 'role','placeholder' => 'Masukkan Role Akses'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="gm">General Manager</option>
                        <option value="am">Areal Manager</option>
                        <option value="admin">Admin</option>
                        <option value="admin-csr">Admin CSR</option>
                        <option value="admin-comrel">Admin Comrel</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        dataTable(8)

        document.addEventListener('DOMContentLoaded', function() {
            Echo.channel('test-user-channel')
            .listen('TestUser', (e) => {
                var user = e.data

                dataTables['dataTable'].row.add([
                        user.nama, user.email, user.departemen, user.nip, user.role
                ]).draw(false)

                if (user.role === "am" || user.role === "gm" ){
                    setSummary("#akunManager")
                } else if (user.role === "admin-csr" || user.role === "admin-comrel" ){
                    setSummary("#akunAdmin")
                }
                
                setSummary("#allUsers")
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\pengguna\index.blade.php ENDPATH**/ ?>