<div class="search-box d-flex">
    <input id="searchInput" type="text" class="search-input" placeholder="Search" autocomplete="off">
    <span id="searchButton" class="btn btn-secondary">
        <?php if (isset($component)) { $__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Search::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Search::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c)): ?>
<?php $attributes = $__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c; ?>
<?php unset($__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c)): ?>
<?php $component = $__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c; ?>
<?php unset($__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c); ?>
<?php endif; ?>
    </span>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\search.blade.php ENDPATH**/ ?>