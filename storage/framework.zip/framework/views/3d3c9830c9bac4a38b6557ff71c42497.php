<?php $__env->startSection('title', 'Dashboard Program'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Tjsl::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.tjsl'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Tjsl::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $attributes = $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $component = $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
    <div class="row">
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Terprogram','value' => ''.e(formatRibuan($total_terprogram)).'','id' => 'jumlahTerprogram'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Program::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.program'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Program::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $attributes = $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $component = $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Tidak Terprogram','color' => 'blue','value' => ''.e(formatRibuan($total_tidak_terprogram)).'','id' => 'jumlahTidakTerprogram'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginalc4a4ce380ed7e6889d08b9d5004e8c6d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc4a4ce380ed7e6889d08b9d5004e8c6d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Unprogram::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.unprogram'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Unprogram::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc4a4ce380ed7e6889d08b9d5004e8c6d)): ?>
<?php $attributes = $__attributesOriginalc4a4ce380ed7e6889d08b9d5004e8c6d; ?>
<?php unset($__attributesOriginalc4a4ce380ed7e6889d08b9d5004e8c6d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc4a4ce380ed7e6889d08b9d5004e8c6d)): ?>
<?php $component = $__componentOriginalc4a4ce380ed7e6889d08b9d5004e8c6d; ?>
<?php unset($__componentOriginalc4a4ce380ed7e6889d08b9d5004e8c6d); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Sponsorship','color' => 'yellow','value' => ''.e(formatRibuan($total_sponsorship)).'','id' => 'jumlahSponsorship'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.svg.icon.program-yellow','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.program-yellow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb)): ?>
<?php $attributes = $__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb; ?>
<?php unset($__attributesOriginalc35e7aad234d6de4ed2a6edd30f91cdb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb)): ?>
<?php $component = $__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb; ?>
<?php unset($__componentOriginalc35e7aad234d6de4ed2a6edd30f91cdb); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Total Anggaran Terpakai','color' => 'red','value' => ''.e(formatRupiah($total_anggaran_terpakai)).'','id' => 'totalAnggaran','footer' => 'dari Anggaran di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal0daf95f74db21f8fb13bc44c365c48c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Currency::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Currency::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2)): ?>
<?php $attributes = $__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2; ?>
<?php unset($__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0daf95f74db21f8fb13bc44c365c48c2)): ?>
<?php $component = $__componentOriginal0daf95f74db21f8fb13bc44c365c48c2; ?>
<?php unset($__componentOriginal0daf95f74db21f8fb13bc44c365c48c2); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Total Sisa Anggaran','color' => 'red','value' => ''.e(formatRupiah($total_anggaran_bersisa)).'','id' => 'totalSisaAnggaran','footer' => 'dari Anggaran di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal0daf95f74db21f8fb13bc44c365c48c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Currency::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.currency'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Currency::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2)): ?>
<?php $attributes = $__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2; ?>
<?php unset($__attributesOriginal0daf95f74db21f8fb13bc44c365c48c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0daf95f74db21f8fb13bc44c365c48c2)): ?>
<?php $component = $__componentOriginal0daf95f74db21f8fb13bc44c365c48c2; ?>
<?php unset($__componentOriginal0daf95f74db21f8fb13bc44c365c48c2); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
    </div>
    <div class="row mt-2 mt-lg-3">
        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 mb-2 mt-lg-0">
            <div class="col-12 charts">
                <h4>Chart Pengajuan</h4>
                <div class="container-fluid">
                    <canvas id="barChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 mb-2 mt-lg-0">
            <div class="col-12 charts">
                <h4>Total Anggaran</h4>
                <div class="container-fluid">
                    <canvas id="anggaranChart"></canvas>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
    <script>
        const labels = <?php echo json_encode($labels, 15, 512) ?>;
        const datax = <?php echo json_encode($datax, 15, 512) ?>;

        const labels2 = <?php echo json_encode($labels2, 15, 512) ?>;
        const datax2 = <?php echo json_encode($datax2, 15, 512) ?>;



        anggaranChart(labels2, datax2, 1000000)
        barChart(labels, datax)

        document.addEventListener('DOMContentLoaded', function() {
            Echo.channel('channel-dashboard-tjsl')
                .listen('DashboardTjslEvent', (e) => {
                    var tjsl = e.data

                    if (tjsl.terprogram === "terprogram") {
                        setSummary("#jumlahTerprogram")
                    } else {
                        setSummary("#jumlahTidakTerprogram")
                    }
                    setAnggaranSummary("#totalAnggaran", tjsl.anggaran)

                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\tjsl\dashboard.blade.php ENDPATH**/ ?>