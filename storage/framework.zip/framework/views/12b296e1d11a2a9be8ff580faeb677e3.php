<div class="modal fade" id="<?php echo e($id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <?php echo e($slot); ?>

            </div>
            <div class="modal-footer">
                <button class="btn btn-primary btn-tutup-modal" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\modals\base-modal.blade.php ENDPATH**/ ?>