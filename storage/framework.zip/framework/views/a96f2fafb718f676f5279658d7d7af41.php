<svg width="30" height="31" viewBox="0 0 30 31" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect y="0.328125" width="30" height="30" rx="5" fill="#D12031" />
    <path
        d="M13 15.3281C12.4477 15.3281 12 15.7758 12 16.3281C12 16.8804 12.4477 17.3281 13 17.3281H17C17.5523 17.3281 18 16.8804 18 16.3281C18 15.7758 17.5523 15.3281 17 15.3281H13Z"
        fill="white" />
    <path fill-rule="evenodd" clip-rule="evenodd"
        d="M5 11.3281C5 12.0684 5.4022 12.7148 6 13.0606V22.3281C6 23.4327 6.89543 24.3281 8 24.3281H22C23.1046 24.3281 24 23.4327 24 22.3281V13.0606C24.5978 12.7148 25 12.0684 25 11.3281V8.32812C25 7.22355 24.1046 6.32812 23 6.32812H7C5.89543 6.32812 5 7.22355 5 8.32812V11.3281ZM7 8.32812V11.3281H23V8.32812H7ZM22 13.3281H8V22.3281H22V13.3281Z"
        fill="white" />
</svg>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\svg\icon\box.blade.php ENDPATH**/ ?>