<?php if(session('alert')): ?>
    <script>
        var data = <?php echo json_encode(session('alert')); ?>


        window.swal.fire({
            title: data['title'] + '!',
            text: data['text'],
            icon: data['type'],
        });
    </script>
<?php endif; ?>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\sweetalert.blade.php ENDPATH**/ ?>