<?php $__env->startSection('title', 'Tentang Pertamina RU II Dumai'); ?>

<?php $__env->startSection('bodyClass', 'body-tentang body-sekilas'); ?>
<?php $__env->startSection('tentang-content'); ?>
    <div class="sekilas ms-5">
        <h3 class="tentang-title">Sekilas Pertamina RU II Dumai</h3>
        <img src="<?php echo e(asset('assets/img/dafault/kilang.jpg')); ?>" alt="Agustiawan Area Manager Comm,Rell & CSR RU II" width="631" height="336" class="rounded">
        <div class="deskripsi mt-2">
            <?php
                $deskripsi = '<p style="line-height: 1.5;">
                Berbagai produk bahan bakar Minyak (BBM) dan Non Bahan Bakar Minyak (NBBM) telah dihasilkan dari kilang Putri
                Tujuh Dumai - Sungai Pakning dan telah didistribusikan ke berbagai pelosok tanah air dan manca negara.
            </p>
            <p style="line-height: 1.5;">
                Sejak dioperasikan pada tahun 1971, kilang minyak Putri Tujuh Dumai dan Sungai Pakning telah memberikan
                sumbangan nyata terhadap perkembangan dan kemajuan daerah khususnya kota Dumai dan sekitarnya dan telah
                memberikan andil yang besar bagi pemenuhan kebutuhan bahan bakar nasional.
            </p>
            <p style="line-height: 1.5;">
                Berbagai produk bahan bakar Minyak (BBM) dan Non Bahan Bakar Minyak (NBBM) telah dihasilkan dari kilang Putri
                Tujuh Dumai - Sungai Pakning dan telah didistribusikan ke berbagai pelosok tanah air dan manca negara.
            </p>
            <p style="line-height: 1.5;">
                Komitmen kami untuk memajukan Kilang Minyak Refinery Unit II Dumai dan Sungai Pakning menjadi Kilang
                Kebanggaan Nasional, sehingga program peningkatan kehandalan kilang dan peningkatan kualitas informasi dan
                komunikasi menjadi penting.
            </p>';
            ?>

            <div class="limited-text-deskripsi">
                <?php echo limitCharacters($deskripsi, 250); ?>

                <a href="##more" onclick="showSelengkapnya(this)">More</a>
            </div>
            <?php if(isLimit($deskripsi, 250)): ?>
                <div class="full-text-deskripsi" style="display: none;">
                    <?php echo $deskripsi; ?>

                    <a href="##less" onclick="showLess(this)">Less</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function showLess(link){
            document.querySelector('.full-text-deskripsi').style.display = 'none'
            document.querySelector('.limited-text-deskripsi').style.display = 'block'
        }

        function showSelengkapnya(link){
            document.querySelector('.limited-text-deskripsi').style.display = 'none'
            document.querySelector('.full-text-deskripsi').style.display = 'block'
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('before-login.tentang.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\tentang\sekilas.blade.php ENDPATH**/ ?>