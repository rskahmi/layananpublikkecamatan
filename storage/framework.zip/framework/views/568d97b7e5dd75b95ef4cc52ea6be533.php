<?php $__env->startSection('headers'); ?>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyClass', 'resume-body'); ?>
<?php $__env->startSection('title', 'Resume'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginald22eef7507bc6b2ab5c4a2cc1c8e4675 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald22eef7507bc6b2ab5c4a2cc1c8e4675 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Resume::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.resume'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Resume::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald22eef7507bc6b2ab5c4a2cc1c8e4675)): ?>
<?php $attributes = $__attributesOriginald22eef7507bc6b2ab5c4a2cc1c8e4675; ?>
<?php unset($__attributesOriginald22eef7507bc6b2ab5c4a2cc1c8e4675); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald22eef7507bc6b2ab5c4a2cc1c8e4675)): ?>
<?php $component = $__componentOriginald22eef7507bc6b2ab5c4a2cc1c8e4675; ?>
<?php unset($__componentOriginald22eef7507bc6b2ab5c4a2cc1c8e4675); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-12 col-xxl-7 mb-3 mb-lg-0">
            <div class="card table">
                <div class="card-header">
                    <h4>Pengajuan Berkas Yang Belum Diverifikasi</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php $__env->slot('slotHeading'); ?>
                            <tr>
                                <th scope="col">BERKAS</th>
                                <th scope="col">BATAS KONFIRMASI</th>
                                <th scope="col">STATUS</th>
                                <th scope="col">AKSI</th>
                            </tr>
                        <?php $__env->endSlot(); ?>


                        <?php $__env->slot('slotBody'); ?>
                            <?php $__currentLoopData = $dataProgramProses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="w-50">
                                        <?php echo e($item['nama_berkas']); ?>

                                    </td>
                                    <td>
                                        <?php echo e(format_dfy($item['batas_konfirmasi'])); ?>

                                    </td>
                                    <td>
                                        <span class="badge <?php echo e(strtolower($item['status']) == 'diajukan' ? 'bg-warning-subtle text-dark' : 'bg-warning'); ?> text-capitalize"><?php echo e($item['status']); ?></span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('berkas.detail', ['id' => $item['id']])); ?>">
                                            <?php if (isset($component)) { $__componentOriginal334a1e8d53b1004ac9cb270596a849ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Info::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Info::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $attributes = $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $component = $__componentOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dataTable']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-xxl-5">
            <div class="row">
                <div class="col-12 col-md-4 col-lg-6 col-x mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Proposal Yang Belum Diverifikasi','color' => 'blue','value' => ''.e(formatRibuan($jumlahProgramProses)).'','id' => 'totalPengajuanProses'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Signin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.signin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Signin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $attributes = $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $component = $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-md-4 col-lg-6 col-x mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Rilis yang Dikeluarkan','color' => 'blue','value' => ''.e(formatRibuan($jumlahMedia)).'','id' => 'jumlahRilis'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Signin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.signin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Signin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $attributes = $__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__attributesOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe)): ?>
<?php $component = $__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe; ?>
<?php unset($__componentOriginala8e6a8cfcef0d0db6bf3d7c601205afe); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-md-4 col-lg-6 col-x mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Total Anggaran Yang Disalurkan untuk TJSL','color' => 'yellow','value' => ''.e(formatRupiah($totalAnggaranTjsl)).'','id' => 'totalAnggaranTjsl'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\CurrencyYellow::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.currency-yellow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\CurrencyYellow::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc)): ?>
<?php $attributes = $__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc; ?>
<?php unset($__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc)): ?>
<?php $component = $__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc; ?>
<?php unset($__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-md-4 col-lg-6 col-x mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Total Anggaran Yang Disalurkan untuk Sponsorship','color' => 'yellow','value' => ''.e(formatRupiah($totalAnggaranSponsorship)).'','id' => 'jumlahStakeholderSponsorship'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\CurrencyYellow::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.currency-yellow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\CurrencyYellow::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc)): ?>
<?php $attributes = $__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc; ?>
<?php unset($__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc)): ?>
<?php $component = $__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc; ?>
<?php unset($__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-md-4 col-lg-6 col-x mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Stakeholder Penerima Manfaat TJSL','color' => 'green','value' => ''.e(formatRibuan($jumlahStakeholderTjsl)).'','id' => 'totalAnggaranTjsl'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Program::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.program'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Program::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $attributes = $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $component = $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-md-4 col-lg-6 col-x mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Stakeholder Penerima Manfaat Sponsorship','color' => 'green','value' => ''.e(formatRibuan($jumlahStakeholderSponsorship)).'','id' => 'jumlahSponsorship'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Program::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.program'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Program::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $attributes = $__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__attributesOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b)): ?>
<?php $component = $__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b; ?>
<?php unset($__componentOriginal0bc840dc4399aa9ca93ddc21966f0b7b); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-12">
            <div class="charts keuangan">
                <div class="title">
                    <div class="row">
                        <div class="col-12 col-md-6 col-xl-5">
                            <h4>Grafik Jumlah Rilis,
                                Berita & Media secara Bulanan</h4>
                        </div>
                        <div class="col-12 col-md-6 col-xl-7">
                            <div class="label">
                                <span>
                                    <span class="icon negatif"></span>&nbsp;Rilis
                                </span>
                                <span>
                                    <span class="icon netral"></span>&nbsp;Pemberitaan
                                </span>
                                <span>
                                    <span class="icon positif"></span>&nbsp;Media
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <canvas id="pengeluaranChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-2">
        <div class="col-12 col-lg-7 mb-3 mb-lg-0">
            <div class="card table">
                <div class="card-header">
                    <h4>Stakeholder Penerima Manfaat TJSL</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dataTable2']); ?>
                        <?php $__env->slot('slotHeading'); ?>
                            <tr>
                                <th scope="col">INSTANSI</th>
                                <th scope="col">JUMLAH ANGGARAN</th>
                                <th scope="col">JUMLAH PROGRAM</th>
                                <th scope="col">AKSI</th>
                            </tr>
                        <?php $__env->endSlot(); ?>

                        <?php $__env->slot('slotBody'); ?>
                            <?php $__currentLoopData = $tjslByStakeholder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($item->nama_lembaga); ?>

                                    </td>
                                    <td>
                                        <?php echo e(formatRupiah($item->jumlah_anggaran)); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->total_program); ?>

                                    </td>
                                    <td>
                                        <a href="##detail"
                                            onclick="showDetailStakeholderTjsl('<?php echo e(route('resume.detailTjsl', ['detail_program' => $item->detail_program])); ?>')">

                                            <?php if (isset($component)) { $__componentOriginal334a1e8d53b1004ac9cb270596a849ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Info::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Info::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $attributes = $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $component = $__componentOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
                </div>
            </div>

            <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dataTable2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-lg-5">
            <div class="charts">
                <h4>Persentase Program TJSL</h4>
                <div class="container-fluid">
                    <canvas id="tjslPieChart" height="211" width="211"></canvas>
                    <div class="label d-flex justify-content-center mt-3">
                        <span>
                            <span class="icon positif"></span>&nbsp;<?php echo e($totalTerprogramTjsl); ?> Terprogram
                        </span>
                        <span>
                            <span class="icon netral"></span>&nbsp;<?php echo e($totalTidakTerprogramTjsl); ?> Tidak Terprogram
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-12 col-lg-7 mb-3 mb-lg-0">
            <div class="card table">
                <div class="card-header">
                    <h4>Stakeholder Penerima Manfaat Sponsorship</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dataTable4']); ?>
                        <?php $__env->slot('slotHeading'); ?>
                            <tr>
                                <th scope="col">NAMA KEGIATAN</th>
                                <th scope="col">JUMLAH ANGGARAN</th>
                                <th scope="col">PIC</th>
                            </tr>
                        <?php $__env->endSlot(); ?>

                        <?php $__env->slot('slotBody'); ?>
                            <?php $__currentLoopData = $dataSponsorship; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($item->nama); ?>

                                    </td>
                                    <td>
                                        <?php echo e(formatRupiah($item->anggaran)); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->pic); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
                </div>
            </div>
            <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dataTable4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
        </div>
        <div class="col-12 col-lg-5">
            <div class="charts">
                <h4>Persentase Pembiayaan Program TJSL & Sponsorship</h4>
                <div class="container-fluid">
                    <canvas id="pumkPieChart"></canvas>
                    <div class="label d-flex justify-content-center mt-3">
                        <span>
                            <span class="icon positif"></span>&nbsp;<?php echo e($jumlahTjsl); ?> TJSL
                        </span>
                        <span>
                            <span class="icon netral"></span>&nbsp;<?php echo e($jumlahSponsorship); ?> Sponsorship
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
    <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'detailTjsl'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__env->slot('slotHeader'); ?>
            <h5 class="modal-title" id="exampleModalLabel">Detail</h5>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('slotBody'); ?>
            <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dataTable3']); ?>
                <?php $__env->slot('slotHeading'); ?>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Program</th>
                        <th scope="col">Anggaran</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">PIC</th>
                    </tr>
                <?php $__env->endSlot(); ?>


                <?php $__env->slot('slotBody'); ?>

                <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dataTable3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('slotFooter'); ?>
            <button type="button" data-bs-dismiss="modal" class="btn btn-primary btn-tutup-modal">Close</button>
        <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chartjs-plugin-datalabels/2.0.0/chartjs-plugin-datalabels.min.js">
    </script>


    <script>
        dataTable(2)
        dataTable(2, "#dataTable2")
        dataTable(4, "#dataTable3")
        dataTable(4, "#dataTable4")


        var canvas = document.getElementById('pengeluaranChart');

        var ctx = canvas.getContext('2d');

        var dataRilis = []
        var dataPemberitaan = []
        var dataMedia = []

        <?php $__currentLoopData = $grafikRilis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            dataRilis.push(<?php echo e($item['total_rilis']); ?>)
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $grafikPemberitaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            dataPemberitaan.push(<?php echo e($item['total_pemberitaan']); ?>)
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $grafikMedia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            dataMedia.push(<?php echo e($item['total_media']); ?>)
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        var data = {
            labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
            datasets: [{
                    label: 'Jumlah Rilis',
                    data: dataRilis,
                    borderColor: '#D12031',
                    borderWidth: 5,
                    fill: false,
                    backgroundColor: '#D12031',
                    tension: 0.5
                },
                {
                    label: 'Jumlah Pemberitaan',
                    data: dataPemberitaan,
                    borderColor: '#145EA8',
                    borderWidth: 5,
                    fill: false,
                    backgroundColor: '#145EA8',
                    tension: 0.5
                },
                {
                    label: 'Jumlah Media',
                    data: dataMedia,
                    borderColor: '#65AE38',
                    borderWidth: 5,
                    fill: false,
                    backgroundColor: '#65AE38',
                    tension: 0.5
                }
            ]
        };

        // Define chart options
        var options = {
            responsive: true,
            title: {
                display: true,
                text: 'Valleys and Peaks Line Chart'
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    }
                },
                y: {
                    grid: {
                        display: false,
                        drawBorder: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            },
        };

        var lineChart = new Chart(ctx, {
            type: 'line',
            data: data,
            options: options
        });

        const tjslLabels = ["Tidak Terprogram", "Terprogram"]
        const tjslData = [<?php echo $totalTidakTerprogramTjsl; ?>, <?php echo $totalTerprogramTjsl; ?>]
        pie("tjslPieChart", tjslLabels, tjslData)

        const pumkLabels = ["Sponsorship", "Tjsl"]
        const pumkData = [<?php echo $jumlahSponsorship; ?>, <?php echo $jumlahTjsl; ?>]
        pie("pumkPieChart", pumkLabels, pumkData)

        document.addEventListener('DOMContentLoaded', function() {
            Echo.channel('channel-dashboard-berkas')
                .listen('DashboardBerkasEvent', (e) => {
                    var berkas = e.data
                    console.log(berkas);

                    if (berkas.hasOwnProperty('deleted_at')) {
                        if(berkas.status.toLowerCase() == 'proses') {
                            unsetSummary("#totalPengajuanBelumVerifikasi")
                        }
                    } else {
                        if(berkas.status.toLowerCase() == 'proses') {
                            unsetSummary("#totalPengajuanBelumVerifikasi")
                        }
                    }
                }
            );
            Echo.channel('channel-dashboard-tjsl')
                .listen('DashboardTjslEvent', (e) => {
                    var tjsl = e.data
                    console.log(tjsl);


                        if (tjsl.lembaga !== null){
                            setSummary("#jumlahStakeholderTjsl")
                        }
                        setAnggaranSummary("#totalAnggaranTjsl", tjsl.anggaran)

                }
            );
            Echo.channel('channel-dashboard-pumk')
                .listen('DashboardPumkEvent', (e) => {
                    var pumk = e.data
                    console.log(pumk);

                    if (pumk.hasOwnProperty('deleted_at')) {
                        unsetSummary("#jumlahStakeholderPumk")
                        unsetAnggaranSummary("#totalAnggaranPumk", pumk.anggaran)
                    } else {
                        setSummary("#jumlahStakeholderPumk")
                        setAnggaranSummary("#totalAnggaranPumk", pumk.anggaran)
                    }

                }
            );
            Echo.channel('channel-dashboard-media')
                .listen('DashboardMediaEvent', (e) => {
                    var media = e.data
                    console.log(media);

                    console.log(media, media.deleted_at !== null);

                    if (media.hasOwnProperty('deleted_at')) {
                        unsetSummary("#jumlahMedia")
                    } else {
                        setSummary("#jumlahMedia")
                    }

                }
            );
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\resume\resume.blade.php ENDPATH**/ ?>