<nav class="main-nav--bg">
    <div class="container-fluid main-nav">
        <div class="main-nav-start">
            <h2 class="main-title"><?php echo $__env->yieldContent('title'); ?></h2>
        </div>
        <div class="main-nav-end">
            <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
                <span class="sr-only">Toggle menu</span>
                <span class="icon menu-toggle--gray" aria-hidden="true"></span>
            </button>
            <div class="nav-user-wrapper">
                <a href="<?php echo e(route('profile')); ?>" class="nav-user-btn dropdown-btn" title="My profile" type="button">
                    <span class="sr-only">My profile</span>
                    <span class="nav-user-img">
                        <picture>
                            <img src="<?php echo e(asset('assets/img/avatar/avatar-2.svg')); ?>" width="30" height="30" alt="<?php echo e(auth()->user()->nama); ?>">
                        </picture>
                    </span>
                    <?php if(auth()->check()): ?>
                        <span>Hi, <?php echo e(auth()->user()->nama); ?></span>
                    <?php else: ?>
                        <script>window.location = "<?php echo e(route('auth')); ?>";</script>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\_partials\user\navbar.blade.php ENDPATH**/ ?>