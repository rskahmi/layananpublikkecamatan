<?php if (isset($component)) { $__componentOriginal89b295b0763c93abe0143426334eb5d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal89b295b0763c93abe0143426334eb5d6 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Label::resolve(['name' => ''.e($name).'','isRequired' => ''.e($isRequired).'','label' => ''.e($label).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Label::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal89b295b0763c93abe0143426334eb5d6)): ?>
<?php $attributes = $__attributesOriginal89b295b0763c93abe0143426334eb5d6; ?>
<?php unset($__attributesOriginal89b295b0763c93abe0143426334eb5d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal89b295b0763c93abe0143426334eb5d6)): ?>
<?php $component = $__componentOriginal89b295b0763c93abe0143426334eb5d6; ?>
<?php unset($__componentOriginal89b295b0763c93abe0143426334eb5d6); ?>
<?php endif; ?>
<div class="input-with-icon">
    <i class="icon">
        <?php if (isset($component)) { $__componentOriginalea5e6c9590e5611d8e67fa3ca7efaf75 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea5e6c9590e5611d8e67fa3ca7efaf75 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Calendar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.calendar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Calendar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea5e6c9590e5611d8e67fa3ca7efaf75)): ?>
<?php $attributes = $__attributesOriginalea5e6c9590e5611d8e67fa3ca7efaf75; ?>
<?php unset($__attributesOriginalea5e6c9590e5611d8e67fa3ca7efaf75); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea5e6c9590e5611d8e67fa3ca7efaf75)): ?>
<?php $component = $__componentOriginalea5e6c9590e5611d8e67fa3ca7efaf75; ?>
<?php unset($__componentOriginalea5e6c9590e5611d8e67fa3ca7efaf75); ?>
<?php endif; ?>
    </i>
    <input
        type="text"
        name="<?php echo e($name); ?>"
        id="<?php echo e($name); ?>"
        class="form-control"
        placeholder="<?php echo e($placeholder); ?>"
        autocomplete="off"
        data-toggle="datepicker"
        <?php if($isRequired): ?>
            required
        <?php endif; ?>
        >
</div>

<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\forms\date.blade.php ENDPATH**/ ?>