<?php $__env->startSection('title', 'Dashboard Media'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal54737db2ce766b8778caa83f377251dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54737db2ce766b8778caa83f377251dc = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Media::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.media'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Media::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54737db2ce766b8778caa83f377251dc)): ?>
<?php $attributes = $__attributesOriginal54737db2ce766b8778caa83f377251dc; ?>
<?php unset($__attributesOriginal54737db2ce766b8778caa83f377251dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54737db2ce766b8778caa83f377251dc)): ?>
<?php $component = $__componentOriginal54737db2ce766b8778caa83f377251dc; ?>
<?php unset($__componentOriginal54737db2ce766b8778caa83f377251dc); ?>
<?php endif; ?>
    <div class="row">
        <div class="col-12 col-lg-4 mb-2">
            <div class="card charts" style="height: 100%;">
                <div class="card-header">
                    <h5 class="card-title bigger">
                        Persentase Jenis Pemberitaan
                    </h5>
                    <h6 class="charts-jumlah"  id="totalPemberitaan" >
                        <?php echo e(formatRibuan($media['total_berita'])); ?>

                    </h6>
                    <p class="mt-2 text-footer">dari Total di tahun ini</p>
                </div>
                <div class="card-body">
                    <div class="chart-body">
                        <canvas id="chartJSContainer" width="450" height="450"></canvas>
                    </div>

                    <div class="label">
                        <span>
                            <span class="icon semi-danger"></span>&nbsp;Media Online
                        </span>
                        <span>
                            <span class="icon warning"></span>&nbsp;Media Cetak
                        </span>
                        <span>
                            <span class="icon more-warning"></span>&nbsp;Media Elektronik
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-8 mb-2">
            <div class="row">
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Rilis','color' => 'yellow','value' => ''.e(formatRibuan($media['total_rilis'])).'','id' => 'totalRilis'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginald70fd8e60c0b21180cd777d7651d4863 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald70fd8e60c0b21180cd777d7651d4863 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Camera::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.camera'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Camera::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald70fd8e60c0b21180cd777d7651d4863)): ?>
<?php $attributes = $__attributesOriginald70fd8e60c0b21180cd777d7651d4863; ?>
<?php unset($__attributesOriginald70fd8e60c0b21180cd777d7651d4863); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald70fd8e60c0b21180cd777d7651d4863)): ?>
<?php $component = $__componentOriginald70fd8e60c0b21180cd777d7651d4863; ?>
<?php unset($__componentOriginald70fd8e60c0b21180cd777d7651d4863); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Berita ','color' => 'green','value' => ''.e(formatRibuan($media['total_berita'])).'','id' => 'totalBerita'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Done::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.done'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Done::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d)): ?>
<?php $attributes = $__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d; ?>
<?php unset($__attributesOriginalfcfca11c6382e5ea7f0c473ea519ce5d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d)): ?>
<?php $component = $__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d; ?>
<?php unset($__componentOriginalfcfca11c6382e5ea7f0c473ea519ce5d); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2">
                    <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Media','color' => 'blue','value' => ''.e(formatRibuan($media['total_media'])).'','footer' => 'dari Program di tahun ini','id' => 'totalMedia'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php if (isset($component)) { $__componentOriginal91cf2bb047551ecf62e5259a86d16abf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91cf2bb047551ecf62e5259a86d16abf = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Noentri::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.noentri'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Noentri::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91cf2bb047551ecf62e5259a86d16abf)): ?>
<?php $attributes = $__attributesOriginal91cf2bb047551ecf62e5259a86d16abf; ?>
<?php unset($__attributesOriginal91cf2bb047551ecf62e5259a86d16abf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91cf2bb047551ecf62e5259a86d16abf)): ?>
<?php $component = $__componentOriginal91cf2bb047551ecf62e5259a86d16abf; ?>
<?php unset($__componentOriginal91cf2bb047551ecf62e5259a86d16abf); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2 mb-lg-0">
                    <div class="card charts rilis" style="height: 100%;">
                        <div class="card-header">
                            <h5 class="card-title bigger">
                                Persentase Respon Berita Online
                            </h5>

                        </div>
                        <div class="card-body">
                            <div class="chart-body">
                                <canvas id="respon-berita-online"></canvas>
                            </div>

                            <div class="label d-flex justify-content-center">
                                <span>
                                    <span class="icon positif"></span>&nbsp;<?php echo e($media["jumlahResponOnline"]["positif"]); ?> Positif
                                </span>
                                <span>
                                    <span class="icon netral"></span>&nbsp;<?php echo e($media["jumlahResponOnline"]["netral"]); ?> Netral
                                </span>
                                <span>
                                    <span class="icon negatif"></span>&nbsp;<?php echo e($media["jumlahResponOnline"]["negatif"]); ?> Negatif
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2 mb-lg-0">
                    <div class="card charts rilis" style="height: 100%;">
                        <div class="card-header">
                            <h5 class="card-title bigger">
                                Persentase Respon Berita Cetak
                            </h5>

                        </div>
                        <div class="card-body">
                            <div class="chart-body">
                                <canvas id="respon-berita-cetak"></canvas>
                            </div>

                            <div class="label d-flex justify-content-center">
                                <span>
                                    <span class="icon positif"></span>&nbsp;<?php echo e($media["jumlahResponCetak"]["positif"]); ?> Positif
                                </span>
                                <span>
                                    <span class="icon netral"></span>&nbsp;<?php echo e($media["jumlahResponCetak"]["netral"]); ?> Netral
                                </span>
                                <span>
                                    <span class="icon negatif"></span>&nbsp;<?php echo e($media["jumlahResponCetak"]["negatif"]); ?> Negatif
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xxl-4 mb-2 mb-lg-0">
                    <div class="card charts rilis" style="height: 100%;">
                        <div class="card-header">
                            <h5 class="card-title bigger">
                                Persentase Respon Berita Elektronik
                            </h5>

                        </div>
                        <div class="card-body">
                            <div class="chart-body">
                                <canvas id="respon-berita-elektronik"></canvas>
                            </div>

                            <div class="label d-flex justify-content-center">
                                <span>
                                    <span class="icon positif"></span>&nbsp;<?php echo e($media["jumlahResponElektronik"]["positif"]); ?> Positif
                                </span>
                                <span>
                                    <span class="icon netral"></span>&nbsp;<?php echo e($media["jumlahResponElektronik"]["netral"]); ?> Netral
                                </span>
                                <span>
                                    <span class="icon negatif"></span>&nbsp;<?php echo e($media["jumlahResponElektronik"]["negatif"]); ?> Negatif
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .chart-container {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .chart-content {
            position: relative;
            display: block;
            width: 150px;
            height: 150px;
        }

        .chart-content canvas {
            display: block;
            max-width: 100%;
            max-height: 100%;
            border-radius: 50%;
            z-index: 2;
        }

        .chart-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            z-index: 1;
            pointer-events: none;
        }

        .chart-percentage {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 32px;
            font-weight: bold;
        }

        .chartPositif .chart-background {
            background-color: rgba(101, 174, 56, 0.25);
        }

        .chartPositif .chart-percentage {
            color: #65AE38;
        }
        .chartNegatif .chart-background {
            background-color: rgba(209, 32, 49, 0.20)
        }

        .chartNegatif .chart-percentage {
            color: #D12031;
        }
        .chartNetral .chart-background {
            background-color: rgba(28, 132, 255, 0.20);
        }

        .chartNetral .chart-percentage {
            color: #1C84FF;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.0/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
    <script>

        var total_media_online = <?php echo $media['total_media_online']; ?>


        var total_media_cetak = <?php echo $media['total_media_cetak']; ?>

        
        var total_media_elektronik = <?php echo $media['total_media_elektronik']; ?>


        var options = {
            type: 'doughnut',
            data: {
                labels: ["Media Online", "Media Cetak", "Media Elektronik"],
                datasets: [{
                    label: 'Persentase Respon Berita',
                    data: [total_media_online, total_media_cetak, total_media_elektronik],
                    backgroundColor: ["#F3722C", "#F8961E","#F94144"]
                }]
            },
            options: {
                rotation: 270,
                circumference: 180,
                plugins: {
                    legend: false,
                    datalabels: {
                        font: {
                            size: 20
                        },
                        color: '#fff',
                        formatter: function(value, context) {
                            var sum = context.dataset.data.reduce((a, b) => a + b, 0);
                            var percentage = Math.round((value / sum) * 100) + '%';
                            return percentage;
                        }
                    }
                }
            },
            plugins: [ChartDataLabels]
        };

        var ctx = document.getElementById('chartJSContainer').getContext('2d');
        new Chart(ctx, options);


        // charts donat
        var labels = [
            'Positif', 'Netral', 'Negatif'
        ]
        var dataOnline = [<?php echo $media["jumlahResponOnline"]["positif"]; ?>, <?php echo $media["jumlahResponOnline"]["netral"]; ?>, <?php echo $media["jumlahResponOnline"]["negatif"]; ?>];
        chartPemberitaan("#respon-berita-online", "Presentase Berita Online", labels, dataOnline);

        var dataCetak = [<?php echo $media["jumlahResponCetak"]["positif"]; ?>, <?php echo $media["jumlahResponCetak"]["netral"]; ?>, <?php echo $media["jumlahResponCetak"]["negatif"]; ?>];
        chartPemberitaan("#respon-berita-cetak", "Presentase Berita Cetak", labels, dataCetak);

        var dataElektronik = [<?php echo $media["jumlahResponElektronik"]["positif"]; ?>, <?php echo $media["jumlahResponElektronik"]["netral"]; ?>, <?php echo $media["jumlahResponElektronik"]["negatif"]; ?>];
        chartPemberitaan("#respon-berita-elektronik", "Presentase Berita Elektronik", labels, dataElektronik);

        document.addEventListener("DOMContentLoaded", function () {
            Echo.channel('channel-dashboard-media')
                .listen('DashboardMediaEvent', (e) => {
                    var media = e.data;

                    if (media.hasOwnProperty('deleted_at')) {
                        unsetSummary("#totalMedia")
                        unsetSummary("#totalRilis")
                        unsetSummary("#totalBerita")
                    } else {
                        setSummary("#totalRilis")
                    }

                        // setSummary("#totalMedia")
                        // setSummary("#totalBerita")
                })
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\media\dashboard.blade.php ENDPATH**/ ?>