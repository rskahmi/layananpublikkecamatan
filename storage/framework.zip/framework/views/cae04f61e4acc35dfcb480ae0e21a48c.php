<svg class="background" width="100%" height="100%" viewBox="0 0 1440 845" fill="none" preserveAspectRatio="none"
    xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd"
        d="M0 582.062L170.487 709.684C397.812 860.395 772.221 693.661 899.328 561.735C1074.73 379.687 1357.26 583.29 1440 757.11V845H0V582.062Z"
        fill="#145EA8" fill-opacity="0.85" />
    <path fill-rule="evenodd" clip-rule="evenodd"
        d="M0 138.378L54 116C138.422 74.2195 185.74 119.45 227.277 159.156C233.957 165.542 240.488 171.785 247 177.5C324.412 245.441 419 96.4181 419 0H0V138.378Z"
        fill="#145EA8" fill-opacity="0.85" />
</svg>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\svg\background.blade.php ENDPATH**/ ?>