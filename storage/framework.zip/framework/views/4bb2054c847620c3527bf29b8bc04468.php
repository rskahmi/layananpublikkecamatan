<?php $__env->startSection('title', 'Monitoring Rilis'); ?>

<?php $__env->startSection('headers'); ?>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal54737db2ce766b8778caa83f377251dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal54737db2ce766b8778caa83f377251dc = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Media::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.media'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Media::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal54737db2ce766b8778caa83f377251dc)): ?>
<?php $attributes = $__attributesOriginal54737db2ce766b8778caa83f377251dc; ?>
<?php unset($__attributesOriginal54737db2ce766b8778caa83f377251dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal54737db2ce766b8778caa83f377251dc)): ?>
<?php $component = $__componentOriginal54737db2ce766b8778caa83f377251dc; ?>
<?php unset($__componentOriginal54737db2ce766b8778caa83f377251dc); ?>
<?php endif; ?>

    <div class="animate__animated animate__fadeInUp">
        <div class="card table">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col-12 col-sm-12 col-md-5">
                        <h4>Data Rilis</h4>
                    </div>
                    <div class="col-12 col-sm-12 col-md-7 d-flex justify-content-start justify-content-md-end gap-2">
                        <?php if (isset($component)) { $__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6)): ?>
<?php $attributes = $__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6; ?>
<?php unset($__attributesOriginal9b33c063a2222f59546ad2a2a9a94bc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6)): ?>
<?php $component = $__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6; ?>
<?php unset($__componentOriginal9b33c063a2222f59546ad2a2a9a94bc6); ?>
<?php endif; ?>
                        <?php if(isAllAdmin()): ?>
                            <button class="btn btn-primary text-capitalize" data-bs-toggle="modal"
                                data-bs-target="#tambahMediaModal">
                                <?php if (isset($component)) { $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Addfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.addfile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Addfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $attributes = $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $component = $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
                                Tambah Rilis
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php $__env->slot('slotHeading'); ?>
                        <tr>
                            <th scope="col" class="w-25">JUDUL</th>
                            <th scope="col" class="w-35">DESKRIPSI</th>
                            <th scope="col">GAMBAR</th>
                            <?php if(isAllAdmin()): ?>
                                <th scope="col" class="text-center">AKSI</th>
                            <?php endif; ?>
                        </tr>
                    <?php $__env->endSlot(); ?>

                    <?php $__env->slot('slotBody'); ?>

                        <?php $__currentLoopData = $rilis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $gambar = isFileExists('storage/images/rilis/' . $item->gambar, asset('assets/img/dafault/default-bg.png'))
                            ?>
                            <tr>
                                <td>
                                    <h5><?php echo e($item->judul); ?></h5>
                                </td>
                                <td>
                                    <div class="limited-text-deskripsi">
                                        <?php echo limitCharacters($item->deskripsi, 170); ?>

                                    </div>
                                    <?php if(isLimit($item->deskripsi, 170)): ?>
                                        <div class="full-text-deskripsi" style="display: none;">
                                            <?php echo $item->deskripsi; ?>

                                        </div>
                                        <a class="text-decoration-underline" href="##more" onclick="showMore(this)">More</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <ul>
                                        <img width="50" height="100%" src="<?php echo e($gambar); ?>" alt="Gambar <?php echo e($item->judul); ?>">
                                    </ul>
                                </td>
                                <?php if(isAllAdmin()): ?>
                                    <td>
                                        <div class="aksi d-flex align-items-center justify-content-center">
                                            <a class="editClassed" href="##edit" id="edit"
                                                onclick="modalEditMedia(
                                    '<?php echo e(route('media.update', ['id' => $item->id])); ?>',
                                    '<?php echo e($item->judul); ?>',
                                    '<?php echo e($item->deskripsi); ?>',
                                    '<?php echo e(asset('storage/images/rilis/' . $item->gambar)); ?>',
                                    '<?php echo e($item->jenis); ?>')"
                                                data-bs-toggle="modal" data-bs-target="#editModal">
                                                <?php if (isset($component)) { $__componentOriginal6a24e45ead027dffc98dad0a673cefeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Edit::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Edit::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $attributes = $__attributesOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__attributesOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb)): ?>
<?php $component = $__componentOriginal6a24e45ead027dffc98dad0a673cefeb; ?>
<?php unset($__componentOriginal6a24e45ead027dffc98dad0a673cefeb); ?>
<?php endif; ?>
                                            </a>
                                            <a href="<?php echo e(route('media.detail', ['id' => $item->id])); ?>">
                                                <?php if (isset($component)) { $__componentOriginal334a1e8d53b1004ac9cb270596a849ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Info::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Info::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $attributes = $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $component = $__componentOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
                                            </a>
                                            <?php if (isset($component)) { $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Delete::resolve(['action' => ''.e(route('media.destroy', ['id' => $item->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.delete'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Delete::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $attributes = $__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__attributesOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6)): ?>
<?php $component = $__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6; ?>
<?php unset($__componentOriginal3d5ffbaafeb1478f3e6e580900aa51a6); ?>
<?php endif; ?>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
    </div>


    <?php if(isAllAdmin()): ?>
        <!-- Modal -->
        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'tambahMediaModal','action' => ''.e(route('media.store')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="exampleModalLabel">Tambah Rilis</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Judul','name' => 'judul','placeholder' => 'Masukkan judul rilis'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal2f60389a9e230471cd863683376c182f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f60389a9e230471cd863683376c182f = $attributes; } ?>
<?php $component = App\View\Components\Forms\Textarea::resolve(['name' => 'deskripsi','label' => 'Deskripsi','placeholder' => 'Masukkan deskripsi rilis'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Textarea::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f60389a9e230471cd863683376c182f)): ?>
<?php $attributes = $__attributesOriginal2f60389a9e230471cd863683376c182f; ?>
<?php unset($__attributesOriginal2f60389a9e230471cd863683376c182f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f60389a9e230471cd863683376c182f)): ?>
<?php $component = $__componentOriginal2f60389a9e230471cd863683376c182f; ?>
<?php unset($__componentOriginal2f60389a9e230471cd863683376c182f); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2 = $attributes; } ?>
<?php $component = App\View\Components\Forms\File::resolve(['name' => 'gambar','label' => 'Gambar','placeholder' => 'Upload Gambar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\File::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $attributes = $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $component = $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'editModal','action' => ''.e(route('media')).'','isUpdate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="exampleModalLabel">Edit Rilis</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Judul','name' => 'edtJudul','placeholder' => 'Masukkan judul media'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal2f60389a9e230471cd863683376c182f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f60389a9e230471cd863683376c182f = $attributes; } ?>
<?php $component = App\View\Components\Forms\Textarea::resolve(['name' => 'edtDeskripsiMedia','label' => 'Deskripsi','placeholder' => 'Masukkan deskripsi media'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Textarea::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f60389a9e230471cd863683376c182f)): ?>
<?php $attributes = $__attributesOriginal2f60389a9e230471cd863683376c182f; ?>
<?php unset($__attributesOriginal2f60389a9e230471cd863683376c182f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f60389a9e230471cd863683376c182f)): ?>
<?php $component = $__componentOriginal2f60389a9e230471cd863683376c182f; ?>
<?php unset($__componentOriginal2f60389a9e230471cd863683376c182f); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <label for="gambarLama">Gambar Lama</label>
                    <img src="" alt="Gambar lama" width="100%" height="129" id="gambarLama">
                </div>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2 = $attributes; } ?>
<?php $component = App\View\Components\Forms\File::resolve(['name' => 'edtGambar','label' => 'Gambar Baru','isRequired' => '0','placeholder' => 'Upload Gambar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\File::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $attributes = $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $component = $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/41.2.0/classic/ckeditor.js"></script>
    <script>
        gambarHandler('gambar')
        gambarHandler('edtGambar')

        dataTable(5)
        createEditor("#deskripsi")
        createEditor("#edtDeskripsiMedia")

        addNewInput("#tautan-plus", "#tautanContainer", false)

        $(".editClassed").click(() => {
            addNewInput("#edt-tautan-plus", "#edtTautanContainer", true)
        })

        removeNewInput('.tautan-min', '.input-group')
        removeNewInput('.edt-tautan-min', '.input-group')
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\media\monitoring.blade.php ENDPATH**/ ?>