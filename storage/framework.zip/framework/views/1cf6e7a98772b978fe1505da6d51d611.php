<?php $__env->startSection('title', 'Tentang Pertamina RU II Dumai'); ?>
<?php $__env->startSection('tentang-content'); ?>
    <div class="sekilas">
        <h3 class="tentang-title">Visi & Misi RU II Dumai</h3>
        <div class="deskripsi mt-3">
            <p class="mt-3" style="line-height: 1.5;">
                <b>Visi</b>: <br> Menjadi kilang minyak dan petrokimia berbasis green dan eco-friendly refinery yang kompetitif berkelas dunia di tahun 2028.
            </p>
            <p class="mt-3" style="line-height: 1.5;">
                <b>Misi</b>: <br>Melakukan usaha dibidang pengolahan minyak dan petrokimia dikelola secara profesional berwawasan lingkungan berdasarkan tata nilai perusahaan untuk memberikan nilai tambah.
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('before-login.tentang.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\tentang\visi-dan-misi.blade.php ENDPATH**/ ?>