<?php $__env->startSection('title', 'Persebaran Program'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container persebaran">
        <div class="page-header">
            <h1>Persebaran Program CSR</h1>
        </div>
        <div class="body">
            <?php if (isset($component)) { $__componentOriginalf978905af90a90a3986446aa027ad0f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf978905af90a90a3986446aa027ad0f2 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Resume::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.resume'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Resume::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <script>
                    const wilayah = <?php echo json_encode($wilayah, 15, 512) ?>
                </script>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf978905af90a90a3986446aa027ad0f2)): ?>
<?php $attributes = $__attributesOriginalf978905af90a90a3986446aa027ad0f2; ?>
<?php unset($__attributesOriginalf978905af90a90a3986446aa027ad0f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf978905af90a90a3986446aa027ad0f2)): ?>
<?php $component = $__componentOriginalf978905af90a90a3986446aa027ad0f2; ?>
<?php unset($__componentOriginalf978905af90a90a3986446aa027ad0f2); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\program-csr.blade.php ENDPATH**/ ?>