<?php $__env->startSection('title', 'Dashboard PUMK'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginalbae7dfa4327ef12172d0b6ccf7a4ab73 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbae7dfa4327ef12172d0b6ccf7a4ab73 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Pumk::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.pumk'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Pumk::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbae7dfa4327ef12172d0b6ccf7a4ab73)): ?>
<?php $attributes = $__attributesOriginalbae7dfa4327ef12172d0b6ccf7a4ab73; ?>
<?php unset($__attributesOriginalbae7dfa4327ef12172d0b6ccf7a4ab73); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbae7dfa4327ef12172d0b6ccf7a4ab73)): ?>
<?php $component = $__componentOriginalbae7dfa4327ef12172d0b6ccf7a4ab73; ?>
<?php unset($__componentOriginalbae7dfa4327ef12172d0b6ccf7a4ab73); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Program','value' => ''.e(formatRibuan($total_pumk)).'','id' => 'totalPumk'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal7ed3c211d5c36ad8151f3ce058063c23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ed3c211d5c36ad8151f3ce058063c23 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Computer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.computer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Computer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ed3c211d5c36ad8151f3ce058063c23)): ?>
<?php $attributes = $__attributesOriginal7ed3c211d5c36ad8151f3ce058063c23; ?>
<?php unset($__attributesOriginal7ed3c211d5c36ad8151f3ce058063c23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ed3c211d5c36ad8151f3ce058063c23)): ?>
<?php $component = $__componentOriginal7ed3c211d5c36ad8151f3ce058063c23; ?>
<?php unset($__componentOriginal7ed3c211d5c36ad8151f3ce058063c23); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Program Lancar','color' => 'blue','value' => ''.e(formatRibuan($jumlah_program_lancar)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal4899ae3307d7fe92d38eb5a5a6eee9eb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4899ae3307d7fe92d38eb5a5a6eee9eb = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\ProgramBlue::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.programBlue'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\ProgramBlue::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4899ae3307d7fe92d38eb5a5a6eee9eb)): ?>
<?php $attributes = $__attributesOriginal4899ae3307d7fe92d38eb5a5a6eee9eb; ?>
<?php unset($__attributesOriginal4899ae3307d7fe92d38eb5a5a6eee9eb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4899ae3307d7fe92d38eb5a5a6eee9eb)): ?>
<?php $component = $__componentOriginal4899ae3307d7fe92d38eb5a5a6eee9eb; ?>
<?php unset($__componentOriginal4899ae3307d7fe92d38eb5a5a6eee9eb); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Program Tidak Lancar','color' => 'red','value' => ''.e(formatRibuan($jumlah_program_tidak_lancar)).'','footer' => 'dari Anggaran di tahun ini','id' => 'totalPumkTidakLancar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginalb1e0ff0436047f3909f2bda4a02d6030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1e0ff0436047f3909f2bda4a02d6030 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Unprogramred::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.unprogramred'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Unprogramred::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1e0ff0436047f3909f2bda4a02d6030)): ?>
<?php $attributes = $__attributesOriginalb1e0ff0436047f3909f2bda4a02d6030; ?>
<?php unset($__attributesOriginalb1e0ff0436047f3909f2bda4a02d6030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1e0ff0436047f3909f2bda4a02d6030)): ?>
<?php $component = $__componentOriginalb1e0ff0436047f3909f2bda4a02d6030; ?>
<?php unset($__componentOriginalb1e0ff0436047f3909f2bda4a02d6030); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
        <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mb-2 mb-lg-0">
            <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Total Anggaran','color' => 'yellow','value' => ''.e(formatRupiah($total_anggaran)).'','id' => 'totalAnggaran'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\CurrencyYellow::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.currencyYellow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\CurrencyYellow::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc)): ?>
<?php $attributes = $__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc; ?>
<?php unset($__attributesOriginal6c0d6821ac6cea90bc44b916a6a44bfc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc)): ?>
<?php $component = $__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc; ?>
<?php unset($__componentOriginal6c0d6821ac6cea90bc44b916a6a44bfc); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="row mt-2 mt-lg-3">
        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 mb-2 mb-lg-0">
            <div class="col-12 charts">
                <h4>Chart Pengajuan</h4>
                <div class="container-fluid">
                    <canvas id="barChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 mb-2 mb-lg-0">
            <div class="col-12 charts">
                <h4>Total Anggaran</h4>
                <div class="container-fluid">
                    <canvas id="anggaranChart"></canvas>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2"></script>
    <script>
        const labels = <?php echo json_encode($labels, 15, 512) ?>;
        const datax = <?php echo json_encode($datax, 15, 512) ?>;

        const labels2 = <?php echo json_encode($labels2, 15, 512) ?>;
        const datax2 = <?php echo json_encode($datax2, 15, 512) ?>;

        anggaranChart(labels2, datax2, 5000000)
        barChart(labels, datax)

        console.log($("#totalAnggaran").text());

        document.addEventListener('DOMContentLoaded', () => {
            Echo.channel('channel-dashboard-pumk')
                .listen('DashboardPumkEvent', (e) => {
                    var pumk = e.data;

                    setSummary("#totalPumk")
                    setSummary("#totalPumkTidakLancar")
                    setAnggaranSummary("#totalAnggaran", pumk.anggaran)
                    if (deleted_at !== null) {
                        unsetSummary("#totalPumk")
                        unsetSummary("#totalPumkTidakLancar")
                        setAnggaranSummary("#totalAnggaran", pumk.anggaran)
                    }

                })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\pumk\dashboard.blade.php ENDPATH**/ ?>