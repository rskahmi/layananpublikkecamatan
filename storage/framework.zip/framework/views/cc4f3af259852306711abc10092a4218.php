<?php $__env->startSection('title', 'Detail Pengajuan'); ?>
<?php $__env->startSection('headers'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/41.2.0/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal8576646e017181f7c8f40714a073405d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8576646e017181f7c8f40714a073405d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Berkas::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.berkas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Berkas::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $attributes = $__attributesOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__attributesOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8576646e017181f7c8f40714a073405d)): ?>
<?php $component = $__componentOriginal8576646e017181f7c8f40714a073405d; ?>
<?php unset($__componentOriginal8576646e017181f7c8f40714a073405d); ?>
<?php endif; ?>

    <?php
        $proposal = $berkas->proposal;
        $riwayat = $berkas->proposal->riwayat;
    ?>

    <div class="row detail-pengajuan">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 animate__animated animate__fadeInLeft">
            <div class="card standart">
                <div class="card-body">
                    <div class="row">
                        <div
                            class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-0 mt-lg-0 mt-xl-0 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Nama Berkas','subtitle' => ''.e($berkas->nama_berkas).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-xl-0 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Nomor Berkas','subtitle' => ''.e($berkas->nomor_berkas).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Jenis','subtitle' => ''.e($berkas->jenis).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Tanggal Diajukan','subtitle' => ''.e(format_dfy($berkas->tanggal)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <?php if($proposal !== null): ?>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3">
                                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Anggaran','subtitle' => ''.e(formatRupiah($proposal->anggaran)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                            </div>
                            
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3">
                                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Total Waktu Proses','subtitle' => ''.e($proposal->total_waktu).' Hari'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3 popup-text">
                                <h6>Status</h6>
                                <span
                                    class="badge text-capitalize
                                    <?php echo e(isStatusDiterima($proposal->status) ? 'bg-success' : (isStatusProses($proposal->status) ? 'bg-warning' : (isStatusDitolak($proposal->status) ? 'bg-danger' : 'bg-warning-subtle text-dark'))); ?>"><?php echo e($proposal->status); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'No HP Pemohon','subtitle' => ''.e($berkas->contact).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <?php if($proposal !== null): ?>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3">
                                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Stakeholder','subtitle' => ''.e($berkas->proposal->lembaga->nama_lembaga).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                            </div>
                            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 mt-2 mt-sm-2 mt-md-3">
                                <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Wilayah','subtitle' => ''.e($proposal->wilayah->alamat . ', ' . $proposal->wilayah->kelurahan . ', ' . $proposal->wilayah->kecamatan).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                            </div>
                            <?php if((isStatusDitolak($proposal->status) || isStatusDiterima($proposal->status)) && !is_null($riwayat)): ?>
                                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3 popup-text">
                                    <h6>Surat Jawaban</h6>
                                    <?php
                                        $index_file = $riwayat->search(function ($item, $key) {
                                            return $item->surat_balasan !== null &&
                                                (strtolower($item->status) == 'diterima' ||
                                                    strtolower($item->status) == 'ditolak');
                                        });

                                        $files = $riwayat[$index_file]->surat_balasan;
                                    ?>
                                    <a target="_blank" href="<?php echo e(asset('storage/surat-balasan/' . $files)); ?>">
                                        <img src="<?php echo e(asset('assets/img/icon/Download.svg')); ?>" alt="Icon Download">
                                        Buka Disini
                                    </a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-3 popup-text">
                            <h6>File <?php echo e($berkas->jenis); ?></h6>
                            <a target="_blank" href="<?php echo e(asset('storage/file-berkas/' . $berkas->file_berkas)); ?>">
                                <img src="<?php echo e(asset('assets/img/icon/Download.svg')); ?>" alt="Icon Download">
                                Buka Disini
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div
            class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-3 mt-sm-3 mt-md-3 mt-xl-0 animate__animated animate__fadeInRight">
            <div class="container ms-0 ms-sm-0 ms-md-0 ms-lg-0 ms-xl-5">
                <?php
                    $lastOfRiwayat = $riwayat->sortBy('created_at')->last();
                ?>

                <?php if(isManagerSection($lastOfRiwayat)): ?>
                    <div class="row">
                        <div class="col-12 popup-text">
                            <h6>Verifikasi Disini</h6>
                        </div>
                        <div class="col-12 mt-2">
                            <div class="d-flex gap-3">
                                <button class="btn btn-warning text-capitalize" data-bs-toggle="modal"
                                    data-bs-target="#modalVerifikasiPengajuan">
                                    Verifikasi
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>


                <?php if(isStaffSection($lastOfRiwayat)): ?>
                    <div class="row">
                        <div class="col-12 popup-text">
                            <h6>Verifikasi Disini</h6>
                        </div>
                        <div class="col-12 mt-2">
                            <div class="d-flex gap-3">
                                <button class="btn btn-warning text-capitalize" data-bs-toggle="modal"
                                    data-bs-target="#modalVerifikasiPengajuan">
                                    Verifikasi
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(isset($riwayat_proposal)): ?>
                    <?php if(count($riwayat_proposal) > 0): ?>
                        <div
                            class="row <?php echo e(!(isStatusDiterima($proposal->status) || isStatusDitolak($proposal->status)) ? 'mt-5' : ''); ?>">
                            <div class="col-12">
                                <h6 class="riwayat-header">Riwayat</h6>
                            </div>
                            <div class="col-12 mt-3">
                                <ul class="timeline">
                                    <?php $__currentLoopData = $riwayat_proposal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="timeline-item">
                                            <div class="date w-auto">
                                                <div class="header">
                                                    <h6><?php echo e(format_dfh($item->created_at)); ?></h6>
                                                </div>
                                                <div class="bottom">
                                                    <?php echo e(format_time($item->created_at)); ?>

                                                </div>
                                            </div>
                                            <div class="circle"></div>
                                            <div class="message-timeline w-auto">
                                                <div class="header">
                                                    <h6 class="status text-capitalize">
                                                        <?php echo e($item->status); ?>

                                                    </h6>
                                                </div>
                                                <div class="bottom text-capitalize">
                                                    Berkas telah
                                                    <?php echo e(strtolower($item->status) == 'proses' ? 'di' : ''); ?>

                                                    <?php echo e($item->status); ?> oleh <?php echo e(roles($item->user->role)); ?>

                                                    <?php if($item->status != 'diajukan'): ?>
                                                        <h6 class="status mt-1 mb-1">
                                                            Pemroses
                                                        </h6>
                                                        <?php echo e($item->user->nama); ?>

                                                        <div class="keterangan">
                                                            <a href="##detail"
                                                                onclick="showReview('<?php echo e($item->alasan); ?>', '<?php echo e($item->user->nama); ?>', '<?php echo e(roles($item->user->role)); ?>')">Lihat
                                                                Keterangan</a>
                                                            <?php if (isset($component)) { $__componentOriginal334a1e8d53b1004ac9cb270596a849ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Info::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Info::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $attributes = $__attributesOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__attributesOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed)): ?>
<?php $component = $__componentOriginal334a1e8d53b1004ac9cb270596a849ed; ?>
<?php unset($__componentOriginal334a1e8d53b1004ac9cb270596a849ed); ?>
<?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($berkas->jenis === 'Proposal'): ?>
        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'modalVerifikasiPengajuan','action' => ''.e(route('berkas.verifikasi', ['id' => $berkas->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'modal-xl']); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="exampleModalLabel">
                    <?php if($proposal !== null && isStatusDiajukan($proposal->status)): ?>
                        Review
                    <?php else: ?>
                        Verifikasi
                    <?php endif; ?>
                    Pengajuan
                </h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <?php if(isManagerSection($lastOfRiwayat)): ?>
                    <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Verifikasi Berkas','name' => 'verifikasi_berkas','placeholder' => 'Pilih diterima atau ditolak'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <option value="diterima">Diterima</option>
                            <option value="ditolak">Ditolak</option>

                            <?php if($lastOfRiwayat->peninjau === 'am' && $lastOfRiwayat->status === 'diajukan'): ?>
                                <option value="review">Review</option>
                            <?php endif; ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                    </div>
                    <div id="onlyDiterima" style="display: none;">
                        <div class="mb-3">
                            <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['name' => 'anggaran','label' => 'Anggaran','placeholder' => 'Masukkan Anggaran','isRequired' => '0'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div id="onlyDireview" style="display: none;">
                        <div class="mb-3">
                            <?php if (isset($component)) { $__componentOriginal67cd5dc9866c6185ad92d933c387fa86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Select::resolve(['label' => 'Pereview','name' => 'peninjau','placeholder' => 'Pilih yang akan melakukan review','isRequired' => '0'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Select::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <option value="admin-comrell">Staff Comm, Rel</option>
                            <option value="admin-csr">Staff CSR</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $attributes = $__attributesOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__attributesOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86)): ?>
<?php $component = $__componentOriginal67cd5dc9866c6185ad92d933c387fa86; ?>
<?php unset($__componentOriginal67cd5dc9866c6185ad92d933c387fa86); ?>
<?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(!($lastOfRiwayat->status === 'proses' && $lastOfRiwayat->peninjau === 'am')): ?>
                    <div class="mb-3">
                        <?php if (isset($component)) { $__componentOriginal2f60389a9e230471cd863683376c182f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f60389a9e230471cd863683376c182f = $attributes; } ?>
<?php $component = App\View\Components\Forms\Textarea::resolve(['name' => 'keterangan','label' => 'Keterangan','placeholder' => 'Masukkan Keterangan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Textarea::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f60389a9e230471cd863683376c182f)): ?>
<?php $attributes = $__attributesOriginal2f60389a9e230471cd863683376c182f; ?>
<?php unset($__attributesOriginal2f60389a9e230471cd863683376c182f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f60389a9e230471cd863683376c182f)): ?>
<?php $component = $__componentOriginal2f60389a9e230471cd863683376c182f; ?>
<?php unset($__componentOriginal2f60389a9e230471cd863683376c182f); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Verifikasi berkas</button>
            <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'modalReviewer'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'modal-xl']); ?>
                <?php $__env->slot('slotHeader'); ?>
                    <h5 class="modal-title" id="exampleModalLabel">Keterangan Review Berkas</h5>
                <?php $__env->endSlot(); ?>

                <?php $__env->slot('slotBody'); ?>
                    <div id="containerReviewer">
                        <div class="mb-3">
                            <h4 class="status mb-1" id="role">Staff</h5>
                                <h4 class="status" id="nama">Josep</h5>
                        </div>
                        <div id="review">
                            Hasil
                        </div>
                    </div>
                <?php $__env->endSlot(); ?>

                <?php $__env->slot('slotFooter'); ?>
                    <button type="button" data-bs-dismiss="modal" class="btn btn-primary btn-tutup-modal">Tutup</button>
                <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        createEditor("#keterangan")
        createEditor("#penolakan")

        currencyInInput("#anggaran")

        gambarHandler("dokumen")

        $('#verifikasi_berkas').change(function() {
            var value = $(this).val()

            if (value.toLowerCase() === "diterima") {
                $('#onlyDiterima').show()
                $('#onlyDireview').hide()
            }else if (value.toLowerCase() === "review") {
                $('#onlyDireview').show()
                $('#onlyDiterima').hide()
            }else {
                $('#onlyDiterima').hide()
                $('#onlyDireview').hide()
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\berkas\detail.blade.php ENDPATH**/ ?>