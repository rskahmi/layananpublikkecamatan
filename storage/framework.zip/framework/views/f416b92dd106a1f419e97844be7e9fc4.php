<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if($action !== ''): ?>
    <form id="form-<?php echo e($id); ?>" action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if($isUpdate): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
<?php endif; ?>
<div class="modal fade admin" id="<?php echo e($id); ?>" data-modal="<?php echo e($modal); ?>" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered <?php echo e($class); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <?php echo e($slotHeader); ?>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e($slotBody); ?>

            </div>
            <div class="modal-footer">
                <?php echo e($slotFooter); ?>

            </div>
        </div>
    </div>
</div>
<?php if($action !== ''): ?>
    </form>
<?php endif; ?>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\modals\admin.blade.php ENDPATH**/ ?>