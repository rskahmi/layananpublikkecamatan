<?php $__env->startSection('title', 'Detail Program'); ?>

<?php $__env->startSection('headers'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Tjsl::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.tjsl'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Tjsl::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $attributes = $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $component = $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
            <div class="card standart">
                <div class="card-body">
                    <div class="row">
                        <div
                            class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-md-0 mt-lg-0 mt-xl-0 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Nama Program','subtitle' => ''.e($tjsl->nama).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-xl-0 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Wilayah','subtitle' => ''.e($tjsl->wilayah->alamat . ', ' . $tjsl->wilayah->kelurahan . ', ' . $tjsl->wilayah->kecamatan).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-xl-0 mt-md-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Tanggal','subtitle' => ''.e(format_dfy($tjsl->tanggal)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-xl-0 mt-md-3 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Lembaga','subtitle' => ''.e($tjsl->lembaga->nama_lembaga).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-xl-0 mt-md-3 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'PIC','subtitle' => ''.e($tjsl->pic).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-xl-0 mt-md-3 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Anggaran','subtitle' => ''.e(formatRupiah($tjsl->anggaran)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-2 mt-sm-2 mt-xl-0 mt-md-3 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'No HP PIC','subtitle' => ''.e($tjsl->contact).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-6 mt-3 mt-sm-3 mt-md-3 mt-xl-0">
            <div class="card table">
                <div class="card-header">
                    <div class="row align-items-center">
                        <div class="col-6">
                            <h4>Rincian Anggaran</h4>
                        </div>
                        <?php if(isAllAdmin()): ?>
                            <div class="col-6 d-flex justify-content-end gap-2">
                                <?php if($anggaranTjsl->isEmpty()): ?>
                                    <button class="btn btn-primary text-capitalize" data-bs-toggle="modal"
                                        data-bs-target="#tambahAnggaran">
                                        <?php if (isset($component)) { $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Addfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.addfile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Addfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $attributes = $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $component = $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
                                        Tambah Anggaran
                                    </button>
                                    <?php endif; ?>
                                    <?php if($anggaranTjsl->last()->sisa_anggaran != 0): ?>
                                        <button class="btn btn-primary text-capitalize" data-bs-toggle="modal"
                                            data-bs-target="#tambahAnggaran">
                                            <?php if (isset($component)) { $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Addfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.addfile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Addfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $attributes = $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $component = $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
                                            Tambah Anggaran
                                        </button>
                                    <?php endif; ?>
                                </div>
                                
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <?php $__env->slot('slotHeading'); ?>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Tujuan Anggaran</th>
                                <th scope="col">Tanggal</th>
                                <th scope="col">Nominal</th>
                                <th scope="col">Sisa Anggaran</th>
                            </tr>
                        <?php $__env->endSlot(); ?>

                        <?php $__env->slot('slotBody'); ?>
                            <?php $__currentLoopData = $anggaranTjsl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($key + 1); ?>

                                    </td>
                                    <td>
                                        <?php echo e($item->tujuan); ?>

                                    </td>
                                    <td>
                                        <?php echo e(format_dfy($item->tanggal)); ?>

                                    </td>
                                    <td>
                                        <?php echo e(formatRupiah($item->nominal)); ?>

                                    </td>
                                    <td>
                                        <?php echo e(formatRupiah($item->sisa_anggaran)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
                </div>
            </div>

            <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
        </div>
    </div>


    <div class="card container-dokumentasi mt-3">
        <div class="card-header">
            <div class="row align-items-center">
                <div class="col-6">
                    <h4>Gambar</h4>
                </div>
                <?php if(isAllAdmin()): ?>
                    <div class="col-6 d-flex justify-content-end gap-2">
                        <button class="btn btn-primary text-capitalize" data-bs-toggle="modal"
                            data-bs-target="#tambahDokumentasi">
                            <?php if (isset($component)) { $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Addfile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.addfile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Addfile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $attributes = $__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__attributesOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d)): ?>
<?php $component = $__componentOriginalc992b099f5181b6c45962da1f9f6ef0d; ?>
<?php unset($__componentOriginalc992b099f5181b6c45962da1f9f6ef0d); ?>
<?php endif; ?>
                            Tambah
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body">
            <div class="owl-carousel">
                <?php $__currentLoopData = $dokumentasTjsl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <?php if (isset($component)) { $__componentOriginale33a47d1ab342a867b2a6f60771f608c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale33a47d1ab342a867b2a6f60771f608c = $attributes; } ?>
<?php $component = App\View\Components\Card\Dokumentasi::resolve(['kegiatan' => ''.e($item->nama_kegiatan).'','tanggal' => ''.e(format_dfy($item->tanggal)).'','gambar' => ''.e(isFileExists('storage/images/dokumentasi-tjsl/' . $item->nama_file, asset('assets/img/dafault/default-bg.png'))).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.dokumentasi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Dokumentasi::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale33a47d1ab342a867b2a6f60771f608c)): ?>
<?php $attributes = $__attributesOriginale33a47d1ab342a867b2a6f60771f608c; ?>
<?php unset($__attributesOriginale33a47d1ab342a867b2a6f60771f608c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale33a47d1ab342a867b2a6f60771f608c)): ?>
<?php $component = $__componentOriginale33a47d1ab342a867b2a6f60771f608c; ?>
<?php unset($__componentOriginale33a47d1ab342a867b2a6f60771f608c); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>


    <?php if(isAllAdmin()): ?>
        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'tambahAnggaran','action' => ''.e(route('anggaran.tjsl.store', ['id' => $tjsl->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="tambahAnggaran">Tambah Anggaran</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Tujuan Anggaran','name' => 'tujuan','placeholder' => 'Masukkan Tujuan Anggaran'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal2c26bbe9b818509eee938912deb14a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c26bbe9b818509eee938912deb14a55 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Date::resolve(['label' => 'Tanggal','name' => 'tanggal','placeholder' => 'Pilih Tanggal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Date::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $attributes = $__attributesOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__attributesOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $component = $__componentOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__componentOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nominal','name' => 'nominal','placeholder' => 'Masukkan Nominal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'tambahDokumentasi','action' => ''.e(route('tjsl.dokumentasi', ['id' => $tjsl->id])).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('slotHeader'); ?>
                <h5 class="modal-title" id="tambahDokumentasi">Tambah Foto/Video</h5>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotBody'); ?>
                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nama Kegiatan','name' => 'nama_kegiatan','placeholder' => 'Masukkan Nama Kegiatan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal2c26bbe9b818509eee938912deb14a55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c26bbe9b818509eee938912deb14a55 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Date::resolve(['label' => 'Tanggal','name' => 'tanggal','placeholder' => 'Pilih Tanggal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Date::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $attributes = $__attributesOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__attributesOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c26bbe9b818509eee938912deb14a55)): ?>
<?php $component = $__componentOriginal2c26bbe9b818509eee938912deb14a55; ?>
<?php unset($__componentOriginal2c26bbe9b818509eee938912deb14a55); ?>
<?php endif; ?>
                </div>

                <div class="mb-3">
                    <?php if (isset($component)) { $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2 = $attributes; } ?>
<?php $component = App\View\Components\Forms\File::resolve(['name' => 'gambar','label' => 'Gambar','placeholder' => 'Upload Gambar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\File::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $attributes = $__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__attributesOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2)): ?>
<?php $component = $__componentOriginal71f75760ce80416d6aa938be1ae7e8b2; ?>
<?php unset($__componentOriginal71f75760ce80416d6aa938be1ae7e8b2); ?>
<?php endif; ?>
                </div>
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('slotFooter'); ?>
                <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
            <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script>
        handlerGambar('gambar')
        dataTable(3)
        currencyInInput("#nominal")

        $(document).ready(function() {
            function calculateItemsToShow() {
                var bodyWidth = $('body').width();
                if (bodyWidth >= 1920) {
                    return 10;
                } else if (bodyWidth >= 1000) {
                    return 5;
                } else if (bodyWidth >= 600) {
                    return 3;
                } else {
                    return 1;
                }
            }


            var itemsCount = $('.owl-carousel .item').length;
            $('.owl-carousel').owlCarousel({
                loop: itemsCount > 3,
                margin: 10,
                items: calculateItemsToShow(),
                responsive: false, // Disable built-in responsive feature
            });

            $(window).resize(function() {
                $('.owl-carousel').trigger('destroy.owl.carousel'); // Destroy the existing carousel
                $('.owl-carousel').owlCarousel({
                    loop: true,
                    margin: 10,
                    items: calculateItemsToShow(),
                    responsive: false, // Disable built-in responsive feature
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\tjsl\detail.blade.php ENDPATH**/ ?>