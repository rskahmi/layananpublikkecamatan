<?php $__env->startSection('title', 'Error Messages'); ?>
<?php $__env->startSection('content'); ?>
    <div class="error-container">
        <img src="<?php echo e(asset('assets/img/dafault/error-min.png')); ?>" alt="Error">
        <h2>Oops!</h2>
        <p>Ini bukan halaman yang ingin saya tuju!</p>
        <a href="<?php echo e(route('beranda')); ?>">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest-no-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\errors\404.blade.php ENDPATH**/ ?>