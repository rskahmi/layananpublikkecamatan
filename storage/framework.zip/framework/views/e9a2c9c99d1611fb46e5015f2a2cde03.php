<div class="card summary">
    <div class="card-header">
        <?php echo e($header); ?>

    </div>
    <div class="card-body d-flex align-items-center">
        <?php echo e($slot); ?>

        <h5 class="<?php echo e($color); ?>" <?php if($id!==""): ?>
        id="<?php echo e($id); ?>"
        <?php endif; ?>><?php echo e($value); ?></h5>
    </div>
    <div class="card-footer">
        <?php echo e($footer ?? ''); ?>

    </div>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\card\summary.blade.php ENDPATH**/ ?>