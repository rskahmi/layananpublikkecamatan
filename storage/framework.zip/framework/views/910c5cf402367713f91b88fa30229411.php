<?php $__env->startSection('title', 'Anggaran Program'); ?>

<?php $__env->startSection('headers'); ?>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Tjsl::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.tjsl'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Tjsl::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $attributes = $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $component = $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>

    <div class="animate__animated animate__fadeInUp">
        <div class="row">
            <div class="col-2 col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-2 mt-2 mt-md-1 mt-lg-0 mt-xl-0 mt-xxl-0">
                <?php if (isset($component)) { $__componentOriginalbc91972c24ea4906e7c3719e985adf63 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc91972c24ea4906e7c3719e985adf63 = $attributes; } ?>
<?php $component = App\View\Components\Card\Summary::resolve(['header' => 'Jumlah Pengeluaran','color' => 'green','value' => ''.e(formatRupiah($total_riwayat_thn_ini)).'','footer' => 'dari Anggaran di tahun ini'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.summary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Summary::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php if (isset($component)) { $__componentOriginale6421fb609a2b45462962e5bf12b92f7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale6421fb609a2b45462962e5bf12b92f7 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Income::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.income'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Income::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale6421fb609a2b45462962e5bf12b92f7)): ?>
<?php $attributes = $__attributesOriginale6421fb609a2b45462962e5bf12b92f7; ?>
<?php unset($__attributesOriginale6421fb609a2b45462962e5bf12b92f7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale6421fb609a2b45462962e5bf12b92f7)): ?>
<?php $component = $__componentOriginale6421fb609a2b45462962e5bf12b92f7; ?>
<?php unset($__componentOriginale6421fb609a2b45462962e5bf12b92f7); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $attributes = $__attributesOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__attributesOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc91972c24ea4906e7c3719e985adf63)): ?>
<?php $component = $__componentOriginalbc91972c24ea4906e7c3719e985adf63; ?>
<?php unset($__componentOriginalbc91972c24ea4906e7c3719e985adf63); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

    <div class="card table mt-5">
        <div class="card-header">
            <div class="row align-items-center">
                <div class="col-6">
                    <h4>Riwayat Anggaran Program Program</h4>
                </div>
                <div class="col-6 d-flex justify-content-end gap-2">
                    <div class="search d-flex">
                        <input id="searchInput" type="text" class="search-input" placeholder="Search" autocomplete="off">
                        <span id="searchButton" class="btn btn-secondary">
                            <?php if (isset($component)) { $__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c = $attributes; } ?>
<?php $component = App\View\Components\Svg\Icon\Search::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.icon.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Icon\Search::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c)): ?>
<?php $attributes = $__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c; ?>
<?php unset($__attributesOriginal18ddfb5d92e8a9a63bd52e041eb2c09c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c)): ?>
<?php $component = $__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c; ?>
<?php unset($__componentOriginal18ddfb5d92e8a9a63bd52e041eb2c09c); ?>
<?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                <?php $__env->slot('slotHeading'); ?>
                    <tr>
                        <th scope="col">NAMA PROGRAM</th>
                        <th scope="col">TUJUAN ANGGARAN</th>
                        <th scope="col">NOMINAL</th>
                        <th scope="col">SISA ANGGARAN</th>
                        <th scope="COL">JENIS</th>
                    </tr>
                <?php $__env->endSlot(); ?>
                <?php $__env->slot('slotBody'); ?>
                    <?php $__currentLoopData = $anggaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($item->tjsl->nama); ?>

                            </td>
                            <td>
                                <h5><?php echo e($item->tujuan); ?></h5>
                                <span><?php echo e(format_dfy($item->tanggal)); ?></span>
                            </td>
                            <td>
                                <?php echo e(formatRupiah($item->nominal)); ?>

                            </td>
                            <td>
                                <?php echo e(formatRupiah($item->sisa_anggaran)); ?>

                            </td>
                            <td>
                                <?php echo e($item->tjsl->jenis); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9 = $attributes; } ?>
<?php $component = App\View\Components\Pagination::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pagination::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $attributes = $__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__attributesOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9)): ?>
<?php $component = $__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9; ?>
<?php unset($__componentOriginald9373deb1a5851d9b00ecd5c1ba52da9); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        dataTable(10)
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\tjsl\anggaran.blade.php ENDPATH**/ ?>