<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
    <path
        d="M12 0C5.37 0 0 5.37 0 12C0 18.63 5.37 24 12 24C18.63 24 24 18.63 24 12C24 5.37 18.63 0 12 0ZM7.5 5.34L12 9.84L16.5 5.34L18.66 7.5L14.16 12L18.66 16.5L16.5 18.66L12 14.16L7.5 18.66L5.34 16.5L9.84 12L5.34 7.5L7.5 5.34Z"
        fill="#D12031" />
</svg>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\svg\icon\close.blade.php ENDPATH**/ ?>