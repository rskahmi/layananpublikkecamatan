<?php $__env->startSection('content'); ?>
    <div class="developer">
        <div class="header">
            <div class="container">
                <img src="<?php echo e(asset('assets/img/logo/logo-simpro-csr.png')); ?>"
                class="logo-simpro" alt="Logo <?php echo e(config('app.name')); ?>"
                    width="71" height="55">
                <span>|</span>
                <img src="<?php echo e(asset('assets/img/logo/logo-kpi.png')); ?>"
                class="logo-kpi" alt="Logo Kilang Pertamina Internasional" width="155"
                    height="49">
            </div>
        </div>
        <div class="body">
            <div class="container">
                <div class="title">
                    <h1>Developer Team</h1>
                </div>
                <div class="member">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-4">
                            <?php if (isset($component)) { $__componentOriginald5e83960650a408ee12cbeeabb323bae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5e83960650a408ee12cbeeabb323bae = $attributes; } ?>
<?php $component = App\View\Components\Card\Developer::resolve(['gambar' => ''.e(asset('assets/img/developer/JRFS.png')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.developer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Developer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $attributes = $__attributesOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__attributesOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $component = $__componentOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__componentOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-4 mt-4 mt-lg-0">
                            <?php if (isset($component)) { $__componentOriginald5e83960650a408ee12cbeeabb323bae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5e83960650a408ee12cbeeabb323bae = $attributes; } ?>
<?php $component = App\View\Components\Card\Developer::resolve(['nama' => 'Anggun Ning Astiti','role' => 'Backend Web Developer','gambar' => ''.e(asset('assets/img/developer/anggun.png')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.developer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Developer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $attributes = $__attributesOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__attributesOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $component = $__componentOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__componentOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-4 mt-4 mt-lg-0">
                            <?php if (isset($component)) { $__componentOriginald5e83960650a408ee12cbeeabb323bae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5e83960650a408ee12cbeeabb323bae = $attributes; } ?>
<?php $component = App\View\Components\Card\Developer::resolve(['nama' => 'Rachel Jeflisa Rahmawati','role' => 'Backend Web Developer','gambar' => ''.e(asset('assets/img/developer/rachel.png')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.developer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Developer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $attributes = $__attributesOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__attributesOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $component = $__componentOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__componentOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-4 mt-4">
                            <?php if (isset($component)) { $__componentOriginald5e83960650a408ee12cbeeabb323bae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5e83960650a408ee12cbeeabb323bae = $attributes; } ?>
<?php $component = App\View\Components\Card\Developer::resolve(['nama' => 'Risky Ahmi','role' => 'Head of UI/UX Designer & System Analyst','gambar' => ''.e(asset('assets/img/developer/risky.png')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.developer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Developer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $attributes = $__attributesOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__attributesOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $component = $__componentOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__componentOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-4 mt-4">
                            <?php if (isset($component)) { $__componentOriginald5e83960650a408ee12cbeeabb323bae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5e83960650a408ee12cbeeabb323bae = $attributes; } ?>
<?php $component = App\View\Components\Card\Developer::resolve(['nama' => 'Putri Amanda Sari','role' => 'UI/UX Designer & System Analyst','gambar' => ''.e(asset('assets/img/developer/amanda.png')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.developer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Developer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $attributes = $__attributesOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__attributesOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $component = $__componentOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__componentOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-4 mt-4">
                            <?php if (isset($component)) { $__componentOriginald5e83960650a408ee12cbeeabb323bae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5e83960650a408ee12cbeeabb323bae = $attributes; } ?>
<?php $component = App\View\Components\Card\Developer::resolve(['nama' => 'Azarine Aprilia Afdal','role' => 'UI/UX Designer','gambar' => ''.e(asset('assets/img/developer/azarine.png')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.developer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Developer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $attributes = $__attributesOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__attributesOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5e83960650a408ee12cbeeabb323bae)): ?>
<?php $component = $__componentOriginald5e83960650a408ee12cbeeabb323bae; ?>
<?php unset($__componentOriginald5e83960650a408ee12cbeeabb323bae); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest-no-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\developer.blade.php ENDPATH**/ ?>