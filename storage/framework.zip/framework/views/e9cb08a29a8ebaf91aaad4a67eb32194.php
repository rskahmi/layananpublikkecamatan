<?php $__env->startSection('title', 'Tentang Pertamina RU II Dumai'); ?>

<?php $__env->startSection('bodyClass', 'body-tentang body-sekilas'); ?>
<?php $__env->startSection('tentang-content'); ?>
    <div class="sejarah">
        <h3 class="tentang-title">Sejarah Pertamina RU II Dumai</h3>
        <img class="w-100" src="<?php echo e(asset('assets/img/dafault/sejarah.png')); ?>"
            alt="Agustiawan Area Manager Comm,Rell & CSR RU II">
        <div class="deskripsi mt-2">
            <?php
                $deskripsi = '<h5> 1969 </h5>
                <p style="line-height: 1.5;">
                    Pembangunan kilang Pertamina Refinery Unit II Dumai ini dilakukan mulai 20 April 1969. Saat itu, pembangunan ini kerja sama antara Pertamina dengan Far East Sumitomo Sloye Kaisha, kontraktor asal Jepang. Kilang tersebut dikukuhkan dalam surat keputusan direktur utama PT Pertamina (Persero) Nomo r 334/Kps/DM/1967.
                    </p>
            <h5>1971</h5>
            <p style="line-height: 1.5;">
                Unit pertama yang didirikan yaitu crude distillation unit (CDU/100) yang selesai pada Juni 1971. Unit ini dirancang untuk mengolah minyak mentah jenis Sumatera Light Crude (SLC) berkapasitas 100 ribu barel per hari.
Selain unit tersebut, didirikan juga unit PL-1 Fixed Bed dan UTL/Offsite.
</p>
            <h5>1981 </h5>
            <p style="line-height: 1.5;">
                Proyek perluasan kilang Dumai dimulai pada tahun 1981 dan setelah selesai pembangunannya diresmikan oleh Presiden RI Soeharto pada 7 tanggal 16 Februari 1984 dengan mengolah LSWR yang dihasilkan oleh Crude Distilling Unit (CDU) kilang Dumai dan kilang Sei Pakning.
    </p>
            <h5>1992 </h5>
            <p style="line-height: 1.5;">
                Pada tahun 1992, kilang dumai menghasilkan 120 ribu barel perhari.
                </p>
            <h5>2007 </h5>
            <p style="line-height: 1.5;">
                Projek perluasan kilang dilakukan lagi pada tahun 2007 dengan merevamp HCU dan HVU serta membangun unit kilang LBO Plant.
                </p>
            <h5>2016 </h5>
            <p style="line-height: 1.5;">
                Pembangunan tangka penerimaan cride baru cap 550 MB dilakukan pada tahun 2016.
                </p>
            <h5>2021 </h5>
            <p style="line-height: 1.5;">
                Pada tahun 2021 dilakukan Gas External Proyek yaitu pemanfaatan gas external sebagai fuel kilang.

                </p>
            <h5>2023 </h5>
            <p style="line-height: 1.5;">
                Pada tahun 2023 kilang PERTAMINA dumai dan pakning menghasilkan 170 ribu barel perhari.
        </p>';
            ?>
            <div class="limited-text-deskripsi">
                <?php echo limitCharacters($deskripsi, 350); ?>

                <a href="##more" onclick="showSelengkapnya(this)">More</a>
            </div>
            <?php if(isLimit($deskripsi, 350)): ?>
                <div class="full-text-deskripsi" style="display: none;">
                    <?php echo $deskripsi; ?>

                    <a href="##less" onclick="showLess(this)">Less</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function showLess(link) {
            document.querySelector('.full-text-deskripsi').style.display = 'none'
            document.querySelector('.limited-text-deskripsi').style.display = 'block'
        }

        function showSelengkapnya(link) {
            document.querySelector('.limited-text-deskripsi').style.display = 'none'
            document.querySelector('.full-text-deskripsi').style.display = 'block'
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('before-login.tentang.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\tentang\sejarah.blade.php ENDPATH**/ ?>