<div class="card produk">
    <img src="<?php echo e($source); ?>" class="card-img-top" alt="Gambar <?php echo e($title); ?>" width="100%" height="100%">
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\card\produk.blade.php ENDPATH**/ ?>