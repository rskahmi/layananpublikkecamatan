    

    <?php $__env->startSection('bodyClass', 'body-berita'); ?>
    <?php $__env->startSection('title', 'Media & Informasi Pertamina RU II Dumai'); ?>
    <?php $__env->startSection('content'); ?>

        <div class="container pemberitaan">
            <div class="page-header">
                <h1>Media & Informasi Pertamina RU II Dumai</h1>
            </div>
            <div class="row">
                <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 col-md-6 col-lg-4 col-xl-3 col-xxl-3 mt-3">
                        <?php if (isset($component)) { $__componentOriginal3ac049d5ced63caf640c892aa207e749 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3ac049d5ced63caf640c892aa207e749 = $attributes; } ?>
<?php $component = App\View\Components\Card\BeritaCard::resolve(['gambar' => ''.e(isFileExists('storage/images/rilis/' . $item->gambar, asset('assets/img/dafault/default-bg.png'))).'','title' => ''.e($item->judul).'','deskripsi' => ''.$item->deskripsi.'','tautan' => ''.e($item->tautan).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.BeritaCard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\BeritaCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                            onclick="beritaPopUp(`<?php echo e($item->judul); ?>`, `<?php echo e(isFileExists('storage/images/rilis/' . $item->gambar, asset('assets/img/dafault/default-bg.png'))); ?>`, `<?php echo e($item->deskripsi); ?>`, <?php echo e($item->pemberitaan); ?>)"
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3ac049d5ced63caf640c892aa207e749)): ?>
<?php $attributes = $__attributesOriginal3ac049d5ced63caf640c892aa207e749; ?>
<?php unset($__attributesOriginal3ac049d5ced63caf640c892aa207e749); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3ac049d5ced63caf640c892aa207e749)): ?>
<?php $component = $__componentOriginal3ac049d5ced63caf640c892aa207e749; ?>
<?php unset($__componentOriginal3ac049d5ced63caf640c892aa207e749); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="pagination" id="pagination">
                <ul>
                    <?php if($berita->onFirstPage()): ?>
                        <li class="disabled"><span>&laquo;</span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($berita->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
                    <?php endif; ?>

                    <?php $__currentLoopData = $berita->getUrlRange(1, $berita->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $berita->currentPage()): ?>
                            <li class="active"><span><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($berita->hasMorePages()): ?>
                        <li><a href="<?php echo e(route('berita', ['page' => $berita->nextPageUrl()])); ?>" rel="next">&raquo;</a></li>
                    <?php else: ?>
                        <li class="disabled"><span>&raquo;</span></li>
                    <?php endif; ?>
                </ul>
            </div>

            <?php if (isset($component)) { $__componentOriginal3c9c42741016133644fbaa55b5e4738c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c9c42741016133644fbaa55b5e4738c = $attributes; } ?>
<?php $component = App\View\Components\Modals\BaseModal::resolve(['id' => 'exampleModal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.BaseModal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\BaseModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <div class="row">
                    <div class="col-12">
                        <h3 class="popup-title" id="judul-berita"></h3>
                    </div>
                    <div class="col-12 mt-2">
                        <img id="gambarBerita" src="" alt="Gambar Pertamina Show 2023" />
                    </div>
                    <div class="col-12">
                        <div class="deskripsi mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Deskripsi','id' => 'deskripsi'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="link">
                            <div class="row">
                                <div class="col-12 popup-text">
                                    <h6>Link</h6>
                                </div>
                                <div class="col-12 mb-2">
                                    <div id="anchor-container">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c9c42741016133644fbaa55b5e4738c)): ?>
<?php $attributes = $__attributesOriginal3c9c42741016133644fbaa55b5e4738c; ?>
<?php unset($__attributesOriginal3c9c42741016133644fbaa55b5e4738c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c9c42741016133644fbaa55b5e4738c)): ?>
<?php $component = $__componentOriginal3c9c42741016133644fbaa55b5e4738c; ?>
<?php unset($__componentOriginal3c9c42741016133644fbaa55b5e4738c); ?>
<?php endif; ?>
        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\berita.blade.php ENDPATH**/ ?>