<?php $__env->startSection('title', 'Tentang Pertamina RU II Dumai'); ?>
<?php $__env->startSection('tentang-content'); ?>

    <div class="sekilas">
        <h3 class="tentang-title">Program Unggulan Comrell & CSR RU II Dumai</h3>
        <div class="row mt-3">
            <?php $__currentLoopData = $program_unggulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-4 mb-3 mb-lg-0">
                    <?php if (isset($component)) { $__componentOriginald3d5a7e4e394911a89530f8df1f453e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3d5a7e4e394911a89530f8df1f453e2 = $attributes; } ?>
<?php $component = App\View\Components\Card\Program::resolve(['badge' => 'UMKM','title' => ''.e($item->nama_program).'','detail' => ''.$item->deskripsi.'','alamat' => ''.e($item->wilayah->alamat).',
                        '.e($item->wilayah->kelurahan).',
                        '.e($item->wilayah->kecamatan).',
                        '.e($item->wilayah->kota).'','kontak' => ''.e(checkNumber($item->contact)).'','gambar' => ''.e(isFileExists('storage/images/program-unggulan/' . $item->gambar, asset('assets/img/dafault/default-bg.png'))).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card.program'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card\Program::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3d5a7e4e394911a89530f8df1f453e2)): ?>
<?php $attributes = $__attributesOriginald3d5a7e4e394911a89530f8df1f453e2; ?>
<?php unset($__attributesOriginald3d5a7e4e394911a89530f8df1f453e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3d5a7e4e394911a89530f8df1f453e2)): ?>
<?php $component = $__componentOriginald3d5a7e4e394911a89530f8df1f453e2; ?>
<?php unset($__componentOriginald3d5a7e4e394911a89530f8df1f453e2); ?>
<?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="pagination" id="pagination">
            <ul>
                <?php if($program_unggulan->onFirstPage()): ?>
                    <li class="disabled"><span>&laquo;</span></li>
                <?php else: ?>
                    <li><a href="<?php echo e($program_unggulan->previousPageUrl()); ?>" rel="prev">&laquo;</a></li>
                <?php endif; ?>

                <?php $__currentLoopData = $program_unggulan->getUrlRange(1, $program_unggulan->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $program_unggulan->currentPage()): ?>
                        <li class="active"><span><?php echo e($page); ?></span></li>
                    <?php else: ?>
                        <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($program_unggulan->hasMorePages()): ?>
                    <li><a href="<?php echo e($program_unggulan->nextPageUrl()); ?>" rel="next">&raquo;</a></li>
                <?php else: ?>
                    <li class="disabled"><span>&raquo;</span></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('before-login.tentang.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\before-login\tentang\program-unggulan.blade.php ENDPATH**/ ?>