<?php $__env->startSection('title', 'Detail Program PUMK'); ?>

<?php $__env->startSection('headers'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Tjsl::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.tjsl'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Tjsl::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $attributes = $__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__attributesOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65)): ?>
<?php $component = $__componentOriginal2f8ce2271c6b3528c051cab6549d9e65; ?>
<?php unset($__componentOriginal2f8ce2271c6b3528c051cab6549d9e65); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-5">
            <div class="card standart">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Nama Usaha','subtitle' => ''.e($pumk->nama_usaha).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Nama Pengusaha','subtitle' => ''.e($pumk->nama_pengusaha).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Tanggal Pengajuan','subtitle' => ''.e($pumk->tanggal).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'No HP Pengusaha','subtitle' => ''.e($pumk->contact).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Wilayah','subtitle' => ''.e($pumk->wilayah->alamat . ', ' . $pumk->wilayah->kelurahan . ', ' . $pumk->wilayah->kecamatan).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Anggaran','subtitle' => ''.e(formatRupiah($pumk->anggaran)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Lembaga','subtitle' => ''.e($pumk->lembaga->nama_lembaga).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Agunan','subtitle' => ''.e($pumk->agunan).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <?php if (isset($component)) { $__componentOriginal3b558cf274d104559a3d58d793ef1cc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6 = $attributes; } ?>
<?php $component = App\View\Components\Text\PopUpMenu::resolve(['title' => 'Jatuh Tempo','subtitle' => ''.e($pumk->jatuh_tempo).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text.PopUpMenu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Text\PopUpMenu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $attributes = $__attributesOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__attributesOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6)): ?>
<?php $component = $__componentOriginal3b558cf274d104559a3d58d793ef1cc6; ?>
<?php unset($__componentOriginal3b558cf274d104559a3d58d793ef1cc6); ?>
<?php endif; ?>
                        </div>
                        <div class="col-6 mt-3">
                            <div class="popup-text">
                                <h6>Status</h6>
                                <span
                                    class="badge <?php echo e(strtolower($pumk->status) === 'lancar' ? 'bg-success' : 'bg-warning'); ?>"><?php echo e($pumk->status); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script>
        handlerGambar('gambar')
        dataTable(3)
        $(document).ready(function() {
            function calculateItemsToShow() {
                var bodyWidth = $('body').width();
                if (bodyWidth >= 1920) {
                    return 10;
                } else if (bodyWidth >= 1000) {
                    return 5;
                } else if (bodyWidth >= 600) {
                    return 3;
                } else {
                    return 1;
                }
            }

            var itemsCount = $('.owl-carousel .item').length;
            $('.owl-carousel').owlCarousel({
                loop: itemsCount > 3,
                margin: 10,
                items: calculateItemsToShow(),
                responsive: false,
            });

            $(window).resize(function() {
                $('.owl-carousel').trigger('destroy.owl.carousel');
                $('.owl-carousel').owlCarousel({
                    loop: true,
                    margin: 10,
                    items: calculateItemsToShow(),
                    responsive: false,
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\pumk\detail.blade.php ENDPATH**/ ?>