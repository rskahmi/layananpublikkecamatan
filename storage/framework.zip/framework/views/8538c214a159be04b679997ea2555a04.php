<div class="card dokumentasi animate__animated animate__fadeInLeft">
    <img src="<?php echo e($gambar); ?>" class="card-img-top" alt="Gambar <?php echo e($kegiatan); ?>">
    <div class="card-body">
        <h5 class="card-title text-center"><?php echo e($kegiatan); ?></h5>
        <p class="card-text text-center">
            <?php echo e($tanggal); ?>

        </p>
    </div>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\card\dokumentasi.blade.php ENDPATH**/ ?>