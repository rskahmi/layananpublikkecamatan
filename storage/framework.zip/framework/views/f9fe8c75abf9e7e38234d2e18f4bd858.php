<div class="popup-text">
    <h6><?php echo e($title); ?></h6>
    <p
        <?php if($id !== ""): ?>
            id="<?php echo e($id); ?>"
        <?php endif; ?>
    >
    <?php echo $subtitle; ?></p>
</div>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\text\pop-up-menu.blade.php ENDPATH**/ ?>