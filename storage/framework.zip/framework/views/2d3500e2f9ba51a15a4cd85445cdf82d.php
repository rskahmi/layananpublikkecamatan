<footer class="footer <?php echo e((!isRouteActive('auth') ? 'w-100' : 'w-50')); ?>">
    <div class="text-center">
        <p class="copyright-text">
            Copyright 2024 CSR RU II Dumai |
            <a href="<?php echo e(route('developer')); ?>" target="_blank"
                rel="noopener noreferrer">
                Simpro Team Developer
            </a>
        </p>
    </div>
</footer>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\layout\_partials\guest\footer.blade.php ENDPATH**/ ?>