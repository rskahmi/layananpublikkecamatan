<?php $__env->startSection('title', 'Profil'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal56651f97ba7a5bb1842245f744019525 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56651f97ba7a5bb1842245f744019525 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Fitur\Profile::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.fitur.profile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Fitur\Profile::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56651f97ba7a5bb1842245f744019525)): ?>
<?php $attributes = $__attributesOriginal56651f97ba7a5bb1842245f744019525; ?>
<?php unset($__attributesOriginal56651f97ba7a5bb1842245f744019525); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56651f97ba7a5bb1842245f744019525)): ?>
<?php $component = $__componentOriginal56651f97ba7a5bb1842245f744019525; ?>
<?php unset($__componentOriginal56651f97ba7a5bb1842245f744019525); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginald0b48f6453422426613907260464fd60 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b48f6453422426613907260464fd60 = $attributes; } ?>
<?php $component = App\View\Components\Svg\Background2::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('svg.background2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Svg\Background2::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b48f6453422426613907260464fd60)): ?>
<?php $attributes = $__attributesOriginald0b48f6453422426613907260464fd60; ?>
<?php unset($__attributesOriginald0b48f6453422426613907260464fd60); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b48f6453422426613907260464fd60)): ?>
<?php $component = $__componentOriginald0b48f6453422426613907260464fd60; ?>
<?php unset($__componentOriginald0b48f6453422426613907260464fd60); ?>
<?php endif; ?>

    <div class="container profile-container">
        <div class="card profile">
            <div class="card-header">
                <img src="<?php echo e(asset('assets/img/avatar/avatar-2.svg')); ?>" alt="Gambar" width="200" height="200">
            </div>
            <div class="card-body">
                <div class="row">

                    <table>
                        <tbody>
                            <tr>
                                <td colspan="2" class="header">Beberapa info yang meliputi identitas diri dan kontak :</td>
                            </tr>
                            <tr>
                                <td class="w-50">Nama Lengkap</td>
                                <td><?php echo e(auth()->user()->nama); ?></td>
                            </tr>
                            <tr >
                                <td class="w-50">E-mail</td>
                                <td> <?php echo e(auth()->user()->email); ?></td>
                            </tr>
                            <tr>
                                <td class="w-50">Nomor Pegawai</td>
                                <td><?php echo e(auth()->user()->nip); ?></td>
                            </tr>
                            <tr>
                                <td class="w-50">Bagian</td>
                                <td><?php echo e(auth()->user()->departemen); ?></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
                <div class="row profile-footer">
                    <div class="col-12 d-flex justify-content-center">
                        <button class="btn btn-primary btn-edt-profile text-capitalize" data-bs-toggle="modal" data-bs-target="#editProfile">Edit Profile</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal7fb18b73413aa142737dfda4cf4b7596 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596 = $attributes; } ?>
<?php $component = App\View\Components\Modals\Admin::resolve(['id' => 'editProfile','action' => ''.e(route('update-profile')).'','isUpdate' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modals.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modals\Admin::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__env->slot('slotHeader'); ?>
            <h5 class="modal-title" id="exampleModalLabel">Edit Profile</h5>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('slotBody'); ?>
            <div class="mb-3">
                <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Nama Lengkap','name' => 'nama','placeholder' => 'Masukkan Nama Lengkap','value' => ''.e(auth()->user()->nama).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
            </div>
            <div class="mb-3">
                <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'No Pegawai','name' => 'nip','placeholder' => 'Masukkan No Pegawai','value' => ''.e(auth()->user()->nip).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
            </div>
            <div class="mb-3">
                <?php if (isset($component)) { $__componentOriginala97611b31e90fc7dc431a34465dcc851 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97611b31e90fc7dc431a34465dcc851 = $attributes; } ?>
<?php $component = App\View\Components\Forms\Input::resolve(['label' => 'Departemen','name' => 'departemen','placeholder' => 'Masukkan Departemen','value' => ''.e(auth()->user()->departemen).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Forms\Input::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $attributes = $__attributesOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__attributesOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97611b31e90fc7dc431a34465dcc851)): ?>
<?php $component = $__componentOriginala97611b31e90fc7dc431a34465dcc851; ?>
<?php unset($__componentOriginala97611b31e90fc7dc431a34465dcc851); ?>
<?php endif; ?>
            </div>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('slotFooter'); ?>
            <button type="submit" class="btn btn-primary btn-tutup-modal">Simpan</button>
        <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $attributes = $__attributesOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__attributesOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596)): ?>
<?php $component = $__componentOriginal7fb18b73413aa142737dfda4cf4b7596; ?>
<?php unset($__componentOriginal7fb18b73413aa142737dfda4cf4b7596); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\after-login\profil\index.blade.php ENDPATH**/ ?>