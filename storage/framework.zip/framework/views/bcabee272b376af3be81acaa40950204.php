<label
    for="<?php echo e($name); ?>"
    class="form-label<?php echo e(($isRequired) ? ' isRequired' : ''); ?>">
    <?php echo e($label); ?>

</label>
<?php /**PATH D:\JRFS\Self\Project\simpro-csr\resources\views\components\forms\label.blade.php ENDPATH**/ ?>